from spider import Spider, SpiderItemType, SpiderSource, SpiderItem, SpiderPlayURL
import os
import re
import json
import time
import requests
from bs4 import BeautifulSoup
from utils import get_image_path
from urllib.parse import urlparse
import xbmcaddon
import xbmcvfs

_ADDON = xbmcaddon.Addon()

localpath = _ADDON.getSettingString('user_path')
if localpath == '':
    localurl  = xbmcvfs.translatePath(os.path.join(_ADDON.getAddonInfo('path'), 'YSDQG.json'))
else:
    localurl  = xbmcvfs.translatePath(os.path.join(localpath, 'YSDQG.json'))

#localurl = 'YSDQG.json'

try:
    with open(localurl, 'r', encoding='utf-8') as f:
        data = f.read()
    jdata = json.loads(data.strip('\n'))
except Exception:
    jdata = {}

if 'YSDQ' in jdata and 'speedLimit' in jdata['YSDQ']:
    spLimit = jdata['YSDQ']['speedLimit']
else:
    spLimit = '1K'
if 'YSDQ' in jdata and 'thlimit' in jdata['YSDQ']:
    thlimit = jdata['YSDQ']['thlimit']
else:
    thlimit = 5
if 'YSDQ' in jdata and 'disableIPV6' in jdata['YSDQ']:
    disableIPV6 = jdata['YSDQ']['disableIPV6']
else:
    disableIPV6 = 'yes'

class SpiderDianShiZhiBo(Spider):

    def name(self):
        return '电视直播'

    def logo(self):
        return get_image_path('dianshi.png')

    def set_post(self):
        return False

    def is_searchable(self):
        return True

    def hide(self):
        return not _ADDON.getSettingBool('data_source_dianshi_switch')

    def list_items(self, parent_item=None, page=1):
        header = {
            "User-Agent": "Mozilla/5.0 (Linux; U; Android 9; zh-cn; MIX 2S Build/PKQ1.180729.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36 XiaoMi/MiuiBrowser/10.1.1"}
        if parent_item is None:
            items = []
            r = requests.get('https://cjk.lm317379829.repl.co/CJK/ITV.json', headers=header)
            datas = json.loads(r.text)
            for data in datas.keys():
                name = data
                id = data
                str = json.dumps(datas[data], ensure_ascii=False)
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        name=name.replace('网络', '数字频道'),
                        id=id,
                        params={
                            'type': 'category',
                            'str': str
                        },
                    ))
            #items.sort(key=lambda i: len(i['name']), reverse=False)
            return items, False
        elif parent_item['params']['type'] == 'category':
            data = json.loads(parent_item['params']['str'])
            items = []
            for video in data:
                cover = 'https://epg.112114.xyz/logo/{}.png'.format(video)
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id=video,
                        name=video,
                        cover=cover,
                        params={
                            'type': 'video',
                        },
                    ))
            return items, False
        elif parent_item['params']['type'] == 'video':
            items = []
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
            }
            url = 'https://cjk.lm317379829.repl.co/IPTV/?page={}&s={}'.format(page,  parent_item['id'])
            r = requests.get(url, headers=header)
            soup = BeautifulSoup(r.content, 'html.parser')
            data = soup.select('div.tables > div.result')
            mpg = soup.select('div[style="display:flex;justify-content:center;"] > a')
            if mpg != []:
                maxpage = int(re.search(r'page=(.*?)&', mpg[-1].get('href')).group(1))
            else:
                maxpage = 1
            nameList = []
            for video in data:
                name = video.select('div.channel > a > div')
                if name == []:
                    continue
                else:
                    name = name[0].get_text().strip()
                purl = video.select('div.m3u8 > table')[0].get_text().strip()
                if name in nameList:
                    num = nameList.index(name)
                    sources = (
                        SpiderSource(
                            'Checked ' + name,
                            {
                                'url': purl,
                             }
                        ))
                    items[num]['sources'].append(sources)
                else:
                    nameList.append(name)
                    sources = []
                    sources.append(
                        SpiderSource(
                            'Checked ' + name,
                            {
                                'url': purl,
                            },
                        ))
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            id='',
                            cover=parent_item['cover'],
                            description='',
                            sources=sources,
                            params={
                                'speedtest': spLimit,
                                'thlimit': thlimit,
                            }
                        ))
            if page < maxpage:
                has_next_page = True
            else:
                has_next_page = False
            return items, has_next_page
        else:
            return [], False

    def resolve_play_url(self, source_params):
        return SpiderPlayURL(source_params['url'])

    def search(self, keyword, page=1):
        items = []
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
        }
        url = 'https://cjk.lm317379829.repl.co/IPTV/?page={}&s={}'.format(page, keyword)
        r = requests.get(url, headers=header)
        soup = BeautifulSoup(r.content, 'html.parser')
        data = soup.select('div.tables > div.result')
        mpg = soup.select('div[style="display:flex;justify-content:center;"] > a')
        if mpg != []:
            maxpage = int(re.search(r'page=(.*?)&', mpg[-1].get('href')).group(1))
        else:
            maxpage = 1
        nameList = []
        for video in data:
            name = video.select('div.channel > a > div')
            if name == []:
                continue
            else:
                name = name[0].get_text().strip()
            purl = video.select('div.m3u8 > table')[0].get_text().strip()
            if name in nameList:
                num = nameList.index(name)
                sources = (
                    SpiderSource(
                        'Checked ' + name,
                        {
                            'url': purl,
                        }
                    ))
                items[num]['sources'].append(sources)
            else:
                nameList.append(name)
                sources = []
                sources.append(
                    SpiderSource(
                        'Checked ' + name,
                        {
                            'url': purl,
                        },
                    ))
                items.append(
                    SpiderItem(
                        type=SpiderItemType.File,
                        name='电视直播：{}'.format(name),
                        id='',
                        cover='',
                        description='',
                        sources=sources,
                        params={
                            'speedtest': spLimit,
                            'thlimit': thlimit,
                        }
                    ))
        if page < maxpage:
            has_next_page = True
        else:
            has_next_page = False
        return items, has_next_page

    def checkPurl(self, source_params, tag):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
        }
        purl = source_params['url']
        try:
            if not purl.endswith('/') and purl.count('/') == 2:
                purl = purl + '/'
            num = re.search(r'://(.*?)/', purl).group(1).count(":")
            if disableIPV6.lower() == 'yes' and num > 4:
                return [{tag: 0}, '']
            r = requests.get(purl, stream=True, allow_redirects=False, headers=header, timeout=5)
            if 'Content-Type' in r.headers and 'video' in r.headers['Content-Type'].lower():
                r.close()
            if 'Location' in r.headers:
                purl = r.headers['Location']
            tspList = self.readM3U8(purl, header, tag)
            return [tspList[0], tspList[1]]
        except:
            return [{tag: 0}, purl]

    def readM3U8(self, url, header, tag):
        url = url.strip('/')
        try:
            r = requests.get(url, headers=header, stream=True, allow_redirects=False, verify=False, timeout=5)
            if 'Content-Type' in r.headers and 'video' in r.headers['Content-Type']:
                r.close()
                return  self.SpeedInfo(url, header, tag, url)
            elif 'Location' in r.headers and '#EXTM3U' not in r.text:
                r.close()
                url = r.headers['Location']
                r = requests.get(url, headers=header, stream=True, allow_redirects=False, verify=False, timeout=5)
            for line in r.iter_lines(8096):
                line = line.decode('utf-8', 'ignore')
                if len(line) > 0 and not line.startswith('#'):
                    if not line.startswith('http'):
                        if line.startswith('/'):
                            line = url[:url.index('/', 8)] + line
                        else:
                            line = url[:url.rindex('/') + 1] + line
                    if line.find(".m3u") != -1 and line.find(".ts") == -1:
                        r.close()
                        return self.readM3U8(line, header, tag)
                    if '.key' not in line:
                        r.close()
                    return self.SpeedInfo(line, header, tag, url)
        except:
            try:
                r.close()
            except:
                pass
            return {tag: 0}

    def SpeedInfo(self, url, header, tag, purl):
        header.update({'Proxy-Connection':'keep-alive'})
        r = requests.get(url, stream=True, headers=header, verify=False, timeout=5)
        count = 0
        count_tmp = 0
        stime = time.time()
        i = 0
        speed = 0
        proxy = 'nomral'
        for chunk in r.iter_content(chunk_size=40960):
            if chunk:
                if i == 2:
                    break
                count += len(chunk)
                sptime = time.time() - stime
                if chunk.startswith(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46') or chunk.startswith(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A') or chunk.startswith(b'\x42\x4D') or chunk.startswith(b'\x47\x49\x46\x38') or chunk.startswith(b'\x4D\x4D') or chunk.startswith(b'\x49\x49') or chunk.startswith(b'\x00\x00\x01\x00') or chunk.startswith(b'\x47'):
                    proxy = 'proxy'
                if count == int(r.headers['content-length']):
                    if sptime > 0:
                        speed = int((count - count_tmp) / sptime)
                    else:
                        speed = 1572864
                if sptime > 0:
                    speed = int((count - count_tmp)/sptime)
                    stime = time.time()
                    count_tmp = count
                    i = i + 1
        return [{tag: speed}, purl, proxy]
