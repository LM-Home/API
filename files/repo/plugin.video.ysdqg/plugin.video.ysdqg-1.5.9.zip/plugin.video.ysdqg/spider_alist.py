from spider import Spider, SpiderItemType, SpiderItem, SpiderSubtitle, SpiderSource, SpiderPlayURL
import os
import re
import json
import requests
from cache import get_cache, set_cache, del_cache
from utils import get_image_path
import xbmcaddon
import xbmcvfs
import xbmcgui

_ADDON = xbmcaddon.Addon()

localpath = _ADDON.getSettingString('user_path')
if localpath == '':
    localurl  = xbmcvfs.translatePath(os.path.join(_ADDON.getAddonInfo('path'), 'YSDQG.json'))
else:
    localurl  = xbmcvfs.translatePath(os.path.join(localpath, 'YSDQG.json'))

#localurl = 'YSDQG.json'

try:
    with open(localurl, 'r', encoding='utf-8') as f:
        data = f.read()
    jdata = json.loads(data.strip('\n'))
except Exception:
    jdata = {}

class SpiderAlist(Spider):

    def name(self):
        return 'Alist网盘'

    def logo(self):
        return get_image_path('alist.png')

    def set_post(self):
        return True

    def is_searchable(self):
        return False

    def hide(self):
        return not _ADDON.getSettingBool('data_source_alist_switch')

    def list_items(self, parent_item=None, page=1):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
        }
        if parent_item is None:
            items = []
            if 'Alist' in jdata and len(jdata['Alist']) != 0:
                for ids in jdata['Alist']:
                    name = ids
                    id = jdata['Alist'][ids]
                    if '@@@' in id:
                        id = jdata['Alist'][ids].split('@@@')[0]
                        username = jdata['Alist'][ids].split('@@@')[1]
                        password = jdata['Alist'][ids].split('@@@')[2]
                    else:
                        username = ''
                        password = ''
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            id=id,
                            name=name,
                            params={
                                'type': 'category',
                                'username': username,
                                'password': password
                            },
                        ))
            else:
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id='https://al.chirmyram.com',
                        name='七米蓝',
                        params={
                            'type': 'category',
                            'username': '',
                            'password': ''
                        },
                    ))
            return items, False

        elif parent_item['params']['type'] == 'category':
            if parent_item['id'].endswith('/'):
                category_id = parent_item['id']
            else:
                category_id = parent_item['id'] + '/'
            baseurl = re.findall(r"http.*://.*?/", category_id)[0]
            header['Referer'] = baseurl
            # get ver start
            ver = get_cache('ver')
            pagetype = get_cache('pagetype')
            if ver == '' or pagetype == '':
                ver, pagetype = self.getVer(baseurl, header)
                set_cache('ver', ver)
                set_cache('pagetype', pagetype)
            # get ver end
            pat = category_id.replace(baseurl, "")
            token = get_cache('token')
            username = parent_item['params']['username']
            password = parent_item['params']['password']
            if password != '' and username != '' and 'Authorization' not in header.keys():
                if token != '':
                    header.update({'Authorization': token})
                else:
                    logurl = baseurl + 'api/auth/login'
                    logparam = {
                        'username': username,
                        'password': password
                    }
                    r = requests.post(logurl, json=logparam, headers=header)
                    jo = json.loads(r.text)
                    if jo['code'] == 200:
                        token = jo['data']['token']
                        header.update({'Authorization': token})
                    else:
                        token = ''
                    set_cache('token', token)
            if pagetype == 'pagination':
                header.update({'Referer': '{}?page={}'.format(parent_item['id'].encode('UTF-8'), page)})
                param = {
                    "path": '/' + pat,
                    "refresh": False,
                    'per_page': 30,
                    'page': page,
                    'password': ''
                }
            elif pagetype == 'all':
                header.update({'Referer': baseurl})
                param = {
                    "path": '/' + pat,
                    "refresh": False,
                    'per_page': 0,
                    'page': page,
                    'password': ''
                }
            else:
                header.update({'Referer': baseurl})
                param = {
                    "path": '/' + pat,
                    "refresh": False,
                    "page": page,
                    "password": ""
                }
            try:
                if ver == '2':
                    r = requests.post(baseurl + 'api/public/path', json=param, headers=header)
                    datas = r.json()
                    total = datas['data']['meta']['total']
                    dataappend = 'files'
                    picappend = 'thumbnail'
                elif ver == '3':
                    r = requests.post(baseurl + 'api/fs/list', json=param, headers=header)
                    datas = r.json()
                    total = datas['data']['total']
                    dataappend = 'content'
                    picappend = 'thumb'
            except Exception:
                xbmcgui.Dialog().notification('提示', '无法打开该链接', get_image_path('alist.png'), 5000, False)
                sys.exit()
            data = datas['data'][dataappend]
            diritems = []
            fileitems = []
            subtitles = []
            data.sort(key=lambda x: (x['name']), reverse=False)
            for video in data:
                if video['type'] == 1:
                    id = category_id + video['name']
                    diritems.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            name=video['name'],
                            id=id,
                            params={
                                'type': 'category',
                                'username': username,
                                'password': password
                            },
                        ))
                else:
                    pic = video[picappend]
                    # 计算文件大小 start
                    size = video['size']
                    if size > 1024 * 1024 * 1024 * 1024.0:
                        fs = "TB"
                        sz = round(size / (1024 * 1024 * 1024 * 1024.0), 2)
                    elif size > 1024 * 1024 * 1024.0:
                        fs = "GB"
                        sz = round(size / (1024 * 1024 * 1024.0), 2)
                    elif size > 1024 * 1024.0:
                        fs = "MB"
                        sz = round(size / (1024 * 1024.0), 2)
                    elif size > 1024.0:
                        fs = "KB"
                        sz = round(size / (1024.0), 2)
                    else:
                        fs = "KB"
                        sz = round(size / (1024.0), 2)
                    # 计算文件大小 end
                    remark = str(sz) + fs
                    endits = video['name'].split('.')[-1]
                    if endits in ['mp4', 'mkv', 'ts', 'TS', 'avi', 'flv', 'rmvb', 'mp3', 'flac', 'wav', 'wma', 'dff']:
                        fileitems.append(
                            SpiderItem(
                                type=SpiderItemType.File,
                                name='{}'.format(video['name']),
                                id=category_id,
                                description='文件大小：{}'.format(remark),
                                cover=pic,
                                subtitles=[],
                                sources=[
                                    SpiderSource(
                                        'Alist网盘',
                                        {
                                            'url': video['name'],
                                            'id': category_id,
                                            'username': username,
                                            'password': password
                                        },
                                    )
                                ],
                            ))
                    elif endits in ['srt', 'ass', 'vtt']:
                        subname = video['name']
                        subtitles.append(SpiderSubtitle(subname, 'alist@@@' + category_id + subname))
            if len(subtitles) != 0 and len(fileitems) != 0:
                for i in range(0, len(fileitems)):
                    fileitems[i]['subtitles'] = subtitles
            items = diritems + fileitems
            if len(data) * page < total:
                has_next_page = True
            else:
                has_next_page = False
            return items, has_next_page
        else:
            return [], False

    def resolve_play_url(self, source_params):
        baseurl = re.findall(r"http.*://.*?/", source_params['id'])[0]
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
            "Referer": baseurl
        }
        url = source_params['id'] + source_params['url']
        # get ver start
        ver = get_cache('ver')
        pagetype = get_cache('pagetype')
        if ver == '' or pagetype == '':
            ver, pagetype = self.getVer(baseurl, header)
            set_cache('ver', ver)
            set_cache('pagetype', pagetype)
            base['baseurl'] = baseurl
        # get ver end
        token = get_cache('token')
        username = source_params['username']
        password = source_params['password']
        if password != '' and username != '' and 'Authorization' not in header.keys():
            if token != '':
                header.update({'Authorization': token})
            else:
                logurl = baseurl + 'api/auth/login'
                logparam = {
                    'username': username,
                    'password': password
                }
                r = requests.post(logurl, json=logparam, headers=header)
                jo = json.loads(r.text)
                if jo['code'] == 200:
                    token = jo['data']['token']
                    header.update({'Authorization': token})
                else:
                    token = ''
                set_cache('token', token)
        param = {
            "path": '/' + url.replace(baseurl, '')
        }
        if ver == '2':
            r = requests.post(baseurl + 'api/public/path', json=param, headers=header)
            purl = r.json()['data']['files'][0]['url']
        elif ver == '3':
            r = requests.post(baseurl + 'api/fs/get', json=param, headers=header)
            purl = r.json()['data']['raw_url']
        if not purl.startswith('http'):
            head = re.findall(r"h.*?:", baseurl)[0]
            purl = head + purl
        return SpiderPlayURL(purl)

    def resolve_subtitles(self, suburl):
        baseurl = re.findall(r"http.*://.*?/", url)[0]
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
            "Referer": baseurl
        }
        url = suburl.split('@@@')[1]

        header.update({'Referer': baseurl})
        token = get_cache('token')
        if 'Authorization' not in header.keys():
            header.update({'Authorization': token})
        # get ver start
        ver = get_cache('ver')
        # get ver end
        param = {
            "path": '/' + url.replace(baseurl, '')
        }
        if ver == '2':
            r = requests.post(baseurl + 'api/public/path', json=param, headers=header)
            suburl = r.json()['data']['files'][0]['url']
        elif ver == '3':
            r = requests.post(baseurl + 'api/fs/get', json=param, headers=header)
            suburl = r.json()['data']['raw_url']
        if suburl.startswith('http') is False:
            head = re.findall(r"h.*?:", baseurl)[0]
            suburl = head + suburl
        return suburl

    def search(self, keyword, page=1):
        return []

    def getVer(self, baseurl, header):
        ver = requests.get(baseurl + 'api/public/settings', headers=header)
        vjo = ver.json()['data']
        if type(vjo) is dict:
            ver = '3'
            pagetype = vjo['pagination_type']
        else:
            ver = '2'
            pagetype = ''
        return ver, pagetype
