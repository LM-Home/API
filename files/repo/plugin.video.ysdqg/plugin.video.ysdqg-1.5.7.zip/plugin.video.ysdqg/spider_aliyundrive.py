from spider import Spider, SpiderItemType, SpiderItem, SpiderSource, SpiderSubtitle, SpiderPlayURL
import os
import re
import sys
import json
import time
import ecdsa
import random
import hashlib
import requests
from proxy import get_proxy_url
from utils import get_image_path
from downloader import Downloader
from cache import get_cache, set_cache, del_cache
import xbmcgui
import xbmcvfs
import xbmcaddon

_ADDON = xbmcaddon.Addon()

base_headers = {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36',
    'Referer': 'https://www.aliyundrive.com/',
}

localpath = _ADDON.getSettingString('user_path')
if localpath == '':
    localurl = xbmcvfs.translatePath(os.path.join(_ADDON.getAddonInfo('path'), 'YSDQG.json'))
else:
    localurl = xbmcvfs.translatePath(os.path.join(localpath, 'YSDQG.json'))

#localurl = 'YSDQG.json'

try:
    with open(localurl, 'r', encoding='utf-8') as f:
        data = f.read()
    jdata = json.loads(data.strip('\n'))
except Exception:
    jdata = {}


class SpiderAliyunDrive(Spider):
    regex_share_id = re.compile(
        r'www.aliyundrive.com\/s\/([^\/]+)(\/folder\/([^\/]+))?')
    cache = {}

    def name(self):
        return '阿里云盘'

    def hide(self):
        return True

    def list_items(self, parent_item=None, page=1):
        if parent_item is None:
            xbmcgui.Dialog().notification('提示', '来晚啦，当前资源已失效', get_image_path('aliyundrive.png'), 5000,
                                          False)
            sys.exit()
            # return [], False

        m = self.regex_share_id.search(parent_item['id'])
        share_id = m.group(1)
        file_id = m.group(3)

        r = requests.post(
            'https://api.aliyundrive.com/adrive/v3/share_link/get_share_by_anonymous',
            json={'share_id': share_id},
            headers=base_headers,
            verify=False)
        share_info = r.json()

        if not 'file_infos' in share_info or len(share_info['file_infos']) == 0:
            xbmcgui.Dialog().notification('提示', '来晚啦，当前资源已失效', get_image_path('aliyundrive.png'), 5000,
                                          False)
            sys.exit()
            # return [], False

        file_info = None
        if file_id:
            for fi in share_info['file_infos']:
                if fi['file_id'] == file_id:
                    file_info = fi
                    break
            if file_info is None:
                file_info = {}
                if 'file_type' not in parent_item['params']:
                    share_token = self._get_share_token(share_id)
                    headers = base_headers.copy()
                    headers['x-share-token'] = share_token

                    r = requests.post(
                        'https://api.aliyundrive.com/adrive/v2/file/get_by_share',
                        json={
                            'fields':
                                '*',
                            'file_id':
                                file_id,
                            'image_thumbnail_process':
                                'image/resize,w_400/format,jpeg',
                            'image_url_process':
                                'image/resize,w_375/format,jpeg',
                            'share_id':
                                share_id,
                            'video_thumbnail_process':
                                'video/snapshot,t_1000,f_jpg,ar_auto,w_375',
                        },
                        headers=headers,
                        verify=False)
                    file_info = r.json()
                else:
                    file_info['type'] = parent_item['params']['file_type']
        else:
            if len(share_info['file_infos']) == 0:
                xbmcgui.Dialog().notification('提示', '来晚啦，当前资源已失效', get_image_path('aliyundrive.png'), 5000,
                                              False)
                sys.exit()
                # return [], False
            file_info = share_info['file_infos'][0]
            file_id = file_info['file_id']

        parent_file_id = None
        if file_info['type'] == 'folder':
            parent_file_id = file_id
        elif file_info['type'] == 'file' and file_info['category'] == 'video':
            parent_file_id = 'root'
        else:
            xbmcgui.Dialog().notification('提示', '来晚啦，当前资源已失效', get_image_path('aliyundrive.png'), 5000,
                                          False)
            sys.exit()
            # return [], False

        dir_infos, video_infos, subtitle_infos = self._list_files(
            share_id,
            parent_file_id,
        )

        items = []

        for dir_info in dir_infos:
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='https://www.aliyundrive.com/s/{}/folder/{}'.format(
                        share_id, dir_info['file_id']),
                    name=dir_info['name'],
                    description='阿里分享链接：\n' + parent_item['id'],
                    cover=share_info['avatar'],
                    params={
                        'type': 'category',
                        'pf': 'ali',
                        'file_type': dir_info['type']
                    }
                ))

        subtitles = []
        subtitle_infos.sort(key=lambda x: x['name'])
        for subtitle_info in subtitle_infos:
            subtitles.append(
                SpiderSubtitle(
                    subtitle_info['name'],
                    get_proxy_url(
                        SpiderAliyunDrive.__name__,
                        self.proxy_download_file.__name__,
                        {
                            'share_id': subtitle_info['share_id'],
                            'file_id': subtitle_info['file_id'],
                            'drive_id': subtitle_info['drive_id'],
                            'oldapi': True
                        },
                    )))

        video_infos.sort(key=lambda x: x['name'])
        display_file_size = _ADDON.getSettingBool(
            'aliyundrive_display_file_size_switch')
        for video_info in video_infos:
            sources = [
                SpiderSource(
                    '原画',
                    {
                        'template_id': '',
                        'share_id': video_info['share_id'],
                        'file_id': video_info['file_id'],
                        'drive_id': video_info['drive_id'],
                        'pf': 'ali'
                    },
                ),
                SpiderSource(
                    '超清',
                    {
                        'template_id': 'FHD',
                        'share_id': video_info['share_id'],
                        'file_id': video_info['file_id'],
                        'drive_id': video_info['drive_id'],
                        'pf': 'ali'
                    },
                ),
                SpiderSource(
                    '高清',
                    {
                        'template_id': 'HD',
                        'share_id': video_info['share_id'],
                        'file_id': video_info['file_id'],
                        'drive_id': video_info['drive_id'],
                        'pf': 'ali'
                    },
                ),
                SpiderSource(
                    '标清',
                    {
                        'template_id': 'SD',
                        'share_id': video_info['share_id'],
                        'file_id': video_info['file_id'],
                        'drive_id': video_info['drive_id'],
                        'pf': 'ali'
                    },
                )
            ]

            if display_file_size:
                desc = '文件大小：{}\n{}'.format(self._sizeof_fmt(video_info['size']), parent_item['id'])
            else:
                desc = '文件大小：{}'.format(self._sizeof_fmt(video_info['size']), parent_item['id'])

            items.append(
                SpiderItem(
                    type=SpiderItemType.File,
                    name=video_info['name'].strip(),
                    sources=sources,
                    cover=share_info['avatar'],
                    description=desc,
                    subtitles=subtitles,
                    params={
                        'pf': 'ali',
                        'file_type': video_info['type']
                    }
                ))

        if len(items) == 0:
            xbmcgui.Dialog().notification('提示', '该链接中无可播放资源', get_image_path('aliyundrive.png'), 5000,
                                          False)
            sys.exit()
        return items, False

    def resolve_play_url(self, source_params):
        if len(source_params['template_id']) == 0:
            params = source_params.copy()
            params['downloader_switch'] = _ADDON.getSettingBool('downloader_switch')
            return SpiderPlayURL(
                get_proxy_url(
                    spider_class=SpiderAliyunDrive.__name__,
                    func_name=self.proxy_download_file.__name__,
                    params=params,
                ))
        else:
            return SpiderPlayURL(
                get_proxy_url(
                    SpiderAliyunDrive.__name__,
                    self.proxy_preview_m3u8.__name__,
                    source_params,
                ))

    def search(self, keyword):
        return []

    def _get_refresh_token(self):
        if 'Ali' in jdata and 'token' in jdata['Ali']:
            if jdata['Ali']['token'].startswith('http://') or jdata['Ali']['token'].startswith('https://'):
                token = requests.get(jdata['Ali']['token']).text.strip().strip('\n')
            else:
                token = jdata['Ali']['token'].strip().strip('\n')
        else:
            if _ADDON.getSettingString('aliyundrive_refresh_token').startswith('http://') or _ADDON.getSettingString(
                    'aliyundrive_refresh_token').startswith('https://'):
                token = requests.get(_ADDON.getSettingString('aliyundrive_refresh_token')).text.strip().strip('\n')
            else:
                token = _ADDON.getSettingString('aliyundrive_refresh_token').strip().strip('\n')
        return token

    def _get_auth(self):
        key = 'aliyundrive:auth'
        data = self._get_cache(key)
        if data:
            return data

        token = self._get_refresh_token()
        r = requests.post('https://auth.aliyundrive.com/v2/account/token',
                          json={
                              'refresh_token': token,
                              'grant_type': 'refresh_token'
                          },
                          headers=base_headers,
                          verify=False)
        data = r.json()

        if 'token_type' not in data:
            xbmcgui.Dialog().notification('提示', '请尝试更换阿里云盘Refresh Token并重启KODI.', get_image_path('aliyundrive.png'), 5000,
                                          False)
            sys.exit()

        authorization = '{} {}'.format(data['token_type'], data['access_token'])
        expires_at = int(time.time()) + int(data['expires_in'] / 2)
        headers = base_headers.copy()
        headers['authorization'] = authorization
        url = 'https://open.aliyundrive.com/oauth/users/authorize?client_id=76917ccccd4441c39457a04f6084fb2f&redirect_uri=https://alist.nn.ci/tool/aliyundrive/callback&scope=user:base,file:all:read,file:all:write&state='
        r = requests.post(url,
                          json={
                              'authorize': 1,
                              'scope': 'user:base,file:all:read,file:all:write'
                          },
                          headers=headers)
        code = re.search(r'code=(.*?)\"', r.text).group(1)
        r = requests.post('https://api.xhofe.top/alist/ali_open/code',
                          json={
                              'code': code,
                              'grant_type': 'authorization_code'
                          },
                          headers=headers)
        opdata = json.loads(r.text)
        try:
            opentoken = opdata['refresh_token']
            opauthorization = '{} {}'.format(opdata['token_type'], opdata['access_token'])
        except:
            opentoken = ''
            opauthorization = ''
        auth = {
            'opentoken': opentoken,
            'opauthorization': opauthorization,
            'authorization': authorization,
            'device_id': data['device_id'],
            'user_id': data['user_id'],
            'drive_id': data['default_drive_id'],
            'expires_at': expires_at
        }

        self._set_cache(key, auth)
        return auth

    def _get_signature(self):
        auth = self._get_auth()

        key = 'aliyundrive:signature'
        data = self._get_cache(key)
        if data and \
                data['device_id'] == auth['device_id'] and \
                data['user_id'] == auth['user_id']:
            return data['signature']

        app_id = '5dde4e1bdf9e4966b387ba58f4b3fdc3'
        nonce = 0
        private_key = random.randint(1, 2 ** 256 - 1)
        ecc_pri = ecdsa.SigningKey.from_secret_exponent(private_key,
                                                        curve=ecdsa.SECP256k1)
        ecc_pub = ecc_pri.get_verifying_key()
        public_key = "04" + ecc_pub.to_string().hex()
        sign_dat = ecc_pri.sign(':'.join(
            [app_id, auth['device_id'], auth['user_id'],
             str(nonce)]).encode('utf-8'),
                                entropy=None,
                                hashfunc=hashlib.sha256)
        signature = sign_dat.hex() + "01"

        headers = base_headers.copy()
        headers['authorization'] = auth['authorization']
        headers['x-device-id'] = auth['device_id']
        headers['x-signature'] = signature

        r = requests.post(
            'https://api.aliyundrive.com/users/v1/users/device/create_session',
            json={
                'deviceName': 'Edge浏览器',
                'modelName': 'Windows网页版',
                'pubKey': public_key,
            },
            headers=headers,
            verify=False)
        result = r.json()
        if 'success' not in result or not result['success']:
            xbmcgui.Dialog().ok('提示', '创建会话失败:\n' + r.text)
            return None
        self._set_cache(
            key, {
                'device_id': auth['device_id'],
                'user_id': auth['user_id'],
                'signature': signature,
            })
        return signature


    def _get_share_token(self, share_id, share_pwd=''):
        key = 'aliyundrive:share_token'
        data = self._get_cache(key)
        if data:
            if data['share_id'] == share_id and data['share_pwd'] == share_pwd:
                return data['share_token']
        r = requests.post(
            'https://api.aliyundrive.com/v2/share_link/get_share_token',
            json={
                'share_id': share_id,
                'share_pwd': share_pwd
            },
            headers=base_headers,
            verify=False)
        data = r.json()
        share_token = data['share_token']
        expires_at = int(time.time()) + int(data['expires_in'] / 2)
        self._set_cache(
            key, {
                'share_token': share_token,
                'expires_at': expires_at,
                'share_id': share_id,
                'share_pwd': share_pwd
            })
        return share_token


    def _list_files(self, share_id, parent_file_id):
        dir_infos = []
        video_infos = []
        subtitle_infos = []
        marker = ''
        share_token = self._get_share_token(share_id)
        headers = base_headers.copy()
        headers['x-share-token'] = share_token
        for page in range(1, 51):
            if page >= 2 and len(marker) == 0:
                break
            r = requests.post(
                'https://api.aliyundrive.com/adrive/v3/file/list',
                json={
                    "image_thumbnail_process":
                        "image/resize,w_160/format,jpeg",
                    "image_url_process": "image/resize,w_1920/format,jpeg",
                    "limit": 200,
                    "order_by": "updated_at",
                    "order_direction": "DESC",
                    "parent_file_id": parent_file_id,
                    "share_id": share_id,
                    "video_thumbnail_process":
                        "video/snapshot,t_1000,f_jpg,ar_auto,w_300",
                    'marker': marker,
                },
                headers=headers,
                verify=False)
            data = r.json()

            for item in data['items']:
                if item['type'] == 'folder':
                    dir_infos.append(item)
                elif item['type'] == 'file' and item['category'] == 'video':
                    video_infos.append(item)
                elif item['type'] == 'file' and item['file_extension'] in [
                    'srt', 'ass', 'vtt'
                ]:
                    subtitle_infos.append(item)

            marker = data['next_marker']

        return dir_infos, video_infos, subtitle_infos


    def _get_m3u8_cache(self, share_id, file_id, template_id, retry=False):
        key = 'aliyundrive:m3u8'
        data = self._get_cache(key)
        if data:
            if data['share_id'] == share_id and data['file_id'] == file_id and data['template_id'] == template_id:
                return data['m3u8'], data['media_urls']

        auth = self._get_auth()
        share_token = self._get_share_token(share_id)

        headers = base_headers.copy()
        headers['authorization'] = auth['authorization']
        headers['x-share-token'] = share_token
        headers['x-device-id'] = auth['device_id']
        headers['x-signature'] = self._get_signature()
        r = requests.post(
            'https://api.aliyundrive.com/v2/file/get_share_link_video_preview_play_info',
            json={
                'share_id': share_id,
                'category': 'live_transcoding',
                'file_id': file_id,
                'template_id': '',
            },
            headers=headers,
            verify=False)

        data = r.json()

        if 'video_preview_play_info' not in data:
            self._del_cache('aliyundrive:signature')
            if retry:
                return self._get_m3u8_cache(share_id, file_id, template_id,
                                            False)
            else:
                raise Exception(r.text)

        preview_url = ''
        for t in data['video_preview_play_info']['live_transcoding_task_list']:
            if t['template_id'] == template_id:
                preview_url = t['url']
                break

        lines = []
        media_urls = []
        r = requests.get(preview_url,
                         headers=base_headers.copy(),
                         stream=True,
                         verify=False)
        media_id = 0
        for line in r.iter_lines():
            line = line.decode()
            if 'x-oss-expires' in line:
                media_url = preview_url[:preview_url.rindex('/') + 1] + line
                media_urls.append(media_url)
                line = get_proxy_url(
                    SpiderAliyunDrive.__name__,
                    self.proxy_preview_media.__name__, {
                        'share_id': share_id,
                        'file_id': file_id,
                        'template_id': template_id,
                        'media_id': media_id
                    })
                media_id += 1
            lines.append(line)
        m3u8 = '\n'.join(lines)

        self._set_cache(
            key, {
                'share_id': share_id,
                'file_id': file_id,
                'template_id': template_id,
                'm3u8': m3u8,
                'media_urls': media_urls,
                'expires_at': int(time.time()) + 60,
            })

        return m3u8, media_urls


    def _get_download_url(self, share_id, file_id, oldapi=False):
        auth = self._get_auth()
        share_token = self._get_share_token(share_id)
        headers = base_headers.copy()
        headers['Content-Type'] = 'application/json'
        headers['x-share-token'] = share_token
        headers['authorization'] = auth['authorization']
        to_drive_id = auth['drive_id']

        key = 'aliyundrive:download_url:{}:{}'.format(share_id, file_id)
        data = self._get_cache(key)
        if data:
            return data['download_url'], bool(data['oldapi'])

        temp_ids = self._get_cache('temp_ids')
        if temp_ids is None:
            temp_ids = []
        else:
            if temp_ids != []:
                self._del_files(headers, to_drive_id, temp_ids)

        if auth['opentoken'] != '':
            try:
                r = self._copy_files(headers, file_id, share_id, to_drive_id)
                if r.status_code == 400:
                    r = requests.post('https://user.aliyundrive.com/v2/user/get', headers=headers)
                    to_drive_id = r.json()['resource_drive_id']
                    r = self._copy_files(headers, file_id, share_id, to_drive_id)
                my_file_id = json.loads(r.text)['responses'][0]['body']['file_id']
                temp_ids.append(my_file_id)
                headers['authorization'] = auth['opauthorization']
                r = requests.post('https://open.aliyundrive.com/adrive/v1.0/openFile/getDownloadUrl',
                                  json={'file_id': my_file_id, 'drive_id': to_drive_id},
                                  headers=headers)
                data = json.loads(r.text)
                download_url = data['url']
            except:
                oldapi = True
            finally:
                if temp_ids != []:
                    headers['authorization'] = auth['authorization']
                    self._del_files(headers, to_drive_id, temp_ids)
        else:
            oldapi = True
        if oldapi:
            r = requests.post(
                'https://api.aliyundrive.com/v2/file/get_share_link_download_url',
                json={
                    'share_id': share_id,
                    'file_id': file_id,
                    'expires_sec': 7200,
                },
                headers=headers,
                verify=False)
            download_url = r.json()['url']

        self._set_cache(
            key, {
                'download_url': download_url,
                'expires_at': int(time.time()) + 600,
                'share_id': share_id,
                'file_id': file_id,
                'oldapi': oldapi
            })
        return download_url, oldapi

    def _copy_files(self, headers, file_id, share_id, to_drive_id):
        json_str = "{\"requests\":[{\"body\":{\"file_id\":\"%s\",\"share_id\":\"%s\",\"auto_rename\":true,\"to_parent_file_id\":\"root\",\"to_drive_id\":\"%s\"},\"headers\":{\"Content-Type\":\"application/json\"},\"id\":\"0\",\"method\":\"POST\",\"url\":\"/file/copy\"}],\"resource\":\"file\"}" % (
        file_id, share_id, to_drive_id)
        r = requests.post('https://api.aliyundrive.com/v3/batch', data=json_str, headers=headers)
        return r

    def _del_files(self, headers, to_drive_id, temp_ids):
        del_ids = []
        for file_id in temp_ids:
            json_str = '{\"requests\":[{\"body\":{\"drive_id\":\"%s\",\"file_id\":\"%s\"},\"headers\":{\"Content-Type\":\"application/json\"},\"id\":\"%s\",\"method\":\"POST\",\"url\":\"/file/delete\"}],\"resource\":\"file\"}' % (to_drive_id, file_id, file_id)
            r = requests.post('https://api.aliyundrive.com/v3/batch', data=json_str, headers=headers)
            if r.status_code == 200 and r.json()['responses'][0]['status'] == 404:
                del_ids.append(file_id)
        for file_id in del_ids:
            temp_ids.remove(file_id)

        if temp_ids != []:
            self._set_cache('temp_ids', temp_ids)
        else:
            self._del_cache('temp_ids')

    def _sizeof_fmt(self, num, suffix="B"):
        for unit in ["", "K", "M", "G", "T", "P", "E", "Z"]:
            if num < 1024.0:
                return f"{num:3.1f} {unit}{suffix}"
            num /= 1024.0
        return f"{num:.1f}Yi{suffix}"

    def _get_cache(self, key):
        if key in self.cache:
            data = self.cache[key]
            if data:
                if 'expires_at' not in data or data['expires_at'] >= int(time.time()):
                    return data

        data = get_cache(key)
        if data:
            data = json.loads(data)
            if 'expires_at' not in data or data['expires_at'] >= int(time.time()) or key == 'temp_ids':
                return data

        return None

    def _set_cache(self, key, value):
        set_cache(key, json.dumps(value))
        self.cache[key] = value

    def _del_cache(self, key):
        del_cache(key)
        self.cache[key] = None

    def proxy_download_file(self, ctx, params):
        share_id = params['share_id']
        file_id = params['file_id']
        if 'oldapi' in params:
            oldapi = params['oldapi']
        else:
            oldapi = False
        downloadUrl, oldapi = self._get_download_url(share_id, file_id, oldapi)
        downloader_switch = params['downloader_switch'] if 'downloader_switch' in params else None

        if downloader_switch or oldapi:
            connection = _ADDON.getSettingInt('downloader_connection')
            if connection == 0:
                connection = 32
            headers = base_headers.copy()
            for key in ctx.headers:
                if key.lower() in [
                    'user-agent',
                    'host',
                ]:
                    continue
                headers[key] = ctx.headers[key]

            def get_url_and_headers():
                return downloadUrl, headers.copy()

            connection = _ADDON.getSettingInt('downloader_connection')
            downloader = Downloader(
                get_url_and_headers=get_url_and_headers,
                headers=headers,
                connection=connection,
            )

            try:
                if 'Range' in ctx.headers:
                    ctx.send_response(206)
                else:
                    ctx.send_response(200)

                res_headers = downloader.start()
                for key in res_headers:
                    if key.lower() in ['connection']:
                        continue
                    value = res_headers[key]
                    ctx.send_header(key, value)
                ctx.end_headers()

                while True:
                    chunk = downloader.read()
                    if chunk is None:
                        break
                    ctx.wfile.write(chunk)
            except:
                pass
            finally:
                try:
                    downloader.stop()
                except:
                    pass
        else:
            self.proxy(ctx, downloadUrl, base_headers.copy())

    def proxy_preview_m3u8(self, ctx, params):
        share_id = params['share_id']
        file_id = params['file_id']
        template_id = params['template_id']
        m3u8, _ = self._get_m3u8_cache(share_id, file_id, template_id)

        try:
            ctx.send_response(200)
            ctx.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            ctx.end_headers()
            ctx.wfile.write(m3u8.encode())
        except:
            pass

    def proxy_preview_media(self, ctx, params):
        share_id = params['share_id']
        file_id = params['file_id']
        template_id = params['template_id']
        media_id = params['media_id']
        _, media_urls = self._get_m3u8_cache(share_id, file_id, template_id, True)
        media_url = media_urls[media_id]
        self.proxy(ctx, media_url, base_headers.copy())
