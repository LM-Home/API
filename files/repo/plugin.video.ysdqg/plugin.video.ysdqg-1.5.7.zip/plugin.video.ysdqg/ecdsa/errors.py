class MalformedPointError(AssertionError):
    """Raised in case the encoding of private or public key is malformed."""

    pass
