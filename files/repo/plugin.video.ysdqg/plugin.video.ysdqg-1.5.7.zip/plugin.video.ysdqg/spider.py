import requests
from base64 import b64decode
from abc import ABC, abstractmethod
from cache import set_cache, get_cache, del_cache


class Spider(ABC):

    @abstractmethod
    def name(self):
        pass

    def logo(self):
        return ''

    def hide(self):
        return False

    def is_searchable(self):
        return False

    @abstractmethod
    def list_items(self, parent_item=None, page=1):
        pass

    @abstractmethod
    def resolve_play_url(self, source_params):
        pass

    def search(self, keyword, page=1):
        pass

    def proxy(self, ctx, url, headers={}, proxyinfos={}):
        proxy_headers = headers.copy()
        for key in ctx.headers:
            if key.lower() in [
                'user-agent',
                'host',
            ]:
                continue
            headers[key] = ctx.headers[key]
        if url == 'base64content':
            url = get_cache('base64content')
            m3u8List = b64decode(url.split('base64,')[1].encode()).decode().splitlines()
            m3u8str = ''
            for line in m3u8List:
                if len(line) > 0 and not line.startswith('#'):
                    if not line.startswith('http'):
                        if line.startswith('/'):
                            line = url[:url.index('/', 8)] + line
                        else:
                            line = url[:url.rindex('/') + 1] + line
                    if 'spider' in proxyinfos and 'function' in proxyinfos:
                        from proxy import get_proxy_url
                        line = get_proxy_url(
                            proxyinfos['spider'],
                            proxyinfos['function'],
                            {
                                'url': line,
                                'headers': proxy_headers,
                                'proxyinfos':{'stripped_image_header': 'True'}
                            },
                        )
                m3u8str += line + '\n'
            # 去广告，删除广告
            if 'adrules' in proxyinfos:
                adrules = proxyinfos['adrules']
            else:
                adrules = []
            regexs = []
            for adrule in adrules:
                break_rec = False
                for host in adrule['hosts']:
                    if host in m3u8str:
                        regexs = adrule['regex']
                        break_rec = True
                        break
                if break_rec:
                    break
            for regex in regexs:
                m3u8str = re.sub(regex, '', m3u8str)
            ctx.send_response(200)
            ctx.send_header('content-type', url.split('base64,')[0].split(':')[1].strip(';'))
            ctx.send_header('content-length', str(len(m3u8str.encode())))
            ctx.end_headers()
            ctx.wfile.write(m3u8str.strip().encode())
        else:
            r = requests.get(url, headers=headers, stream=True, verify=False)
            try:
                if 'content_type' in proxyinfos:
                    content_type = proxyinfos['content_type']
                    r.headers['Content-Type'] = content_type
                else:
                    content_type = r.headers['content-type']
                ctx.send_response(r.status_code)
                for key in r.headers:
                    if key.lower() in ['connection', 'transfer-encoding']:
                        continue
                    if content_type.lower() in ['application/vnd.apple.mpegurl', 'application/x-mpegurl']:
                        if key.lower() in ['content-length', 'content-range', 'accept-ranges']:
                            continue
                    ctx.send_header(key, r.headers[key])
                ctx.end_headers()

                if content_type.lower() in ['application/vnd.apple.mpegurl', 'application/x-mpegurl']:
                    m3u8str = ''
                    for line in r.iter_lines(8192):
                        line = line.decode()
                        if len(line) > 0 and not line.startswith('#'):
                            if not line.startswith('http'):
                                if line.startswith('/'):
                                    line = url[:url.index('/', 8)] + line
                                else:
                                    line = url[:url.rindex('/') + 1] + line
                            if 'spider' in proxyinfos and 'function' in proxyinfos:
                                from proxy import get_proxy_url
                                line = get_proxy_url(
                                    proxyinfos['spider'],
                                    proxyinfos['function'],
                                    {
                                        'url': line,
                                        'headers': proxy_headers,
                                        'proxyinfos':{'stripped_image_header': 'True'}
                                    },
                                )
                        m3u8str += line + '\n'
                    # 去广告，删除广告
                    if 'adrules' in proxyinfos:
                        adrules = proxyinfos['adrules']
                    else:
                        adrules = []
                    regexs = []
                    for adrule in adrules:
                        break_rec = False
                        for host in adrule['hosts']:
                            if host in m3u8str:
                                regexs = adrule['regex']
                                break_rec = True
                                break
                        if break_rec:
                            break
                    for regex in regexs:
                        m3u8str = re.sub(regex, '', m3u8str)
                    ctx.wfile.write(m3u8str.strip().encode())
                else:
                    stripped_image_header = False
                    if 'stripped_image_header' in proxyinfos and proxyinfos['stripped_image_header'] == 'True':
                        stripped_image_header = True
                    for chunk in r.iter_content(8192):
                        if stripped_image_header:
                            chunk = chunk.lstrip(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46')
                            chunk = chunk.lstrip(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A')
                            chunk = chunk.lstrip(b'\x47\x49\x46\x38\x37\x61')
                            chunk = chunk.lstrip(b'\x00\x00\x01\x00')
                            chunk = chunk.lstrip(b'\x47\x49\x46\x38\x39\x61')
                            chunk = chunk.lstrip(b'\x42\x4D\x5A\x27\x4C')
                            chunk = chunk.lstrip(b'\x42\x4D')
                            chunk = chunk.lstrip(b'\x49\x49')
                            stripped_image_header = False
                        ctx.wfile.write(chunk)
            except:
                pass
            finally:
                try:
                    r.close()
                except:
                    pass

class SpiderItemType(object):
    File = 'file'
    Directory = 'directory'
    Search = 'search'


def SpiderSource(name, params):
    return {
        'name': name,
        'params': params,
    }


def SpiderDanmaku(name, url):
    return {
        'name': name,
        'url': url,
    }


def SpiderSubtitle(name, url):
    return {
        'name': name,
        'url': url,
    }


def SpiderItem(
    type,
    name,
    id='',
    cover='',
    description='',
    director='',
    cast=[],
    area='',
    year=0,
    sources=[],
    danmakus=[],
    subtitles=[],
    params={},
):
    return {
        'type': type,
        'id': str(id).strip(),
        'name': name.strip(),
        'cover': cover,
        'description': description.strip(),
        'cast': cast,
        'director': director,
        'area': area,
        'year': int(year),
        'sources': sources,
        'danmakus': danmakus,
        'subtitles': subtitles,
        'params': params,
    }


def SpiderPlayURL(url, danmakus=[], subtitles=[]):
    set_cache('played', 'True')
    return {
        'url': url,
        'danmakus': danmakus,
        'subtitles': subtitles,
    }
