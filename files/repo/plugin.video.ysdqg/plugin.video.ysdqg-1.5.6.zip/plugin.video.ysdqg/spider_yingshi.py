from spider import Spider, SpiderItemType, SpiderSource, SpiderDanmaku, SpiderItem, SpiderPlayURL, SpiderSubtitle
from spider_aliyundrive import SpiderAliyunDrive
import os
import re
import sys
import time
import json
import string
import base64
import urllib
import difflib
import hashlib
import requests
from aes import AES
import concurrent.futures
from bs4 import BeautifulSoup
from collections import OrderedDict

from proxy import get_proxy_url
from urllib.parse import urlparse
from danmaku import get_danmaku_url
from cache import get_cache, set_cache, del_cache
from utils import get_image_path, remove_html_tags, cleanText
import xbmcaddon
import xbmcgui
import xbmcvfs

_ADDON = xbmcaddon.Addon()

try:
    bbexists = True
    from spider_bilibili import Spiderbilibili
except:
    bbexists = False

localpath = _ADDON.getSettingString('user_path')
if localpath == '':
    localurl  = xbmcvfs.translatePath(os.path.join(_ADDON.getAddonInfo('path'), 'YSDQG.json'))
else:
    localurl  = xbmcvfs.translatePath(os.path.join(localpath, 'YSDQG.json'))
bbhide = Spiderbilibili.hide(Spiderbilibili())

#localurl = 'YSDQG.json'

try:
    with open(localurl, 'r', encoding='utf-8') as f:
        data = f.read()
    jdata = json.loads(data.strip('\n'))
except:
    jdata = {}

if 'YSDQ' in jdata and 'speedLimit' in jdata['YSDQ']:
    spLimit = jdata['YSDQ']['speedLimit']
else:
    spLimit = '1K'
if 'YSDQ' in jdata and 'thlimit' in jdata['YSDQ']:
    thlimit = jdata['YSDQ']['thlimit']
else:
    thlimit = 5
if 'YSDQ' in jdata and 'adrules' in jdata['YSDQ']:
    adrules = jdata['YSDQ']['adrules']
else:
    adrules = []

class Spideryingshi(Spider):

    def name(self):
        return '影视'

    def logo(self):
        return get_image_path('yingshi.png')

    def hide(self):
        return not _ADDON.getSettingBool('data_source_yingshi_switch')

    def set_post(self):
        return True

    def is_searchable(self):
        return True

    def list_items(self, parent_item=None, page=1):
        if parent_item is None:
            items = []
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='recommend',
                    name='高分电影',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='hot_gaia',
                    name='电影',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='剧集',
                    name='剧集',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='show_hot',
                    name='综艺',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            return items, False
        elif parent_item['params']['type'] == 'category':
            if parent_item['params']['pf'] == 'db':
                items = []
                header = {
                    "Host": "frodo.douban.com",
                    "Connection": "Keep-Alive",
                    "Referer": "https://servicewechat.com/wx2f9b06c1de1ccfca/84/page-frame.html",
                    "content-type": "application/json",
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36 MicroMessenger/7.0.9.501 NetType/WIFI MiniProgramEnv/Windows WindowsWechat"
                }
                tag = parent_item['id']
                idname = parent_item['name']
                if idname == '剧集':
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            id='tv_hot',
                            name='全部剧集',
                            params={
                                'type': 'category',
                                'pf': 'db'
                            },
                        ))
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            id='tv_domestic',
                            name='国产剧',
                            params={
                                'type': 'category',
                                'pf': 'db'
                            },
                        ))
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            id='tv_american',
                            name='美剧',
                            params={
                                'type': 'category',
                                'pf': 'db'
                            },
                        ))
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            id='tv_japanese',
                            name='日剧',
                            params={
                                'type': 'category',
                                'pf': 'db'
                            },
                        ))
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            id='tv_korean',
                            name='韩剧',
                            params={
                                'type': 'category',
                                'pf': 'db'
                            },
                        ))
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            id='tv_animation',
                            name='动画',
                            params={
                                'type': 'category',
                                'pf': 'db'
                            },
                        ))
                    return items, False
                elif '电影' in idname:
                    url = 'https://frodo.douban.com/api/v2/movie/{}'.format(tag)
                    if tag == 'recommend':
                        params = {'tags': '', 'sort': 'T', 'refresh': 0, 'selected_categories': '{"类型":"","地区":""}', 'start': (int(page) - 1) * 30, 'count': 30, 'apikey': '0ac44ae016490db2204ce0a042db2916'}
                    elif tag == 'hot_gaia':
                        params = {'area': '全部', 'sort': 'recommend', 'start': ((int(page) - 1) * 30), 'count': 30, 'apikey': '0ac44ae016490db2204ce0a042db2916'}
                    r = requests.get(url, headers=header, params=params, timeout=5)
                    data = json.loads(cleanText(r.text))
                    append = 'items'
                elif idname in ['综艺', '动画', '日剧', '韩剧', '美剧', '国产剧', '全部剧集']:
                    url = 'https://frodo.douban.com/api/v2/subject_collection/{}/items'.format(tag)
                    params = {'start': (int(page) - 1) * 30, 'count': 30, 'apikey': '0ac44ae016490db2204ce0a042db2916'}
                    r = requests.get(url, headers=header, params=params, timeout=5)
                    data = json.loads(cleanText(r.text))
                    append = 'subject_collection_items'
                for video in data[append]:
                    vid = video['id']
                    voddesc = video['comment']
                    if type(voddesc) == dict:
                        voddesc = voddesc['comment']
                    imgurl = re.sub(r'photo/(.*?)/', 'photo/l/', video['pic']['large'])
                    imgcode = re.search(r'public/p(.*?).jpg', video['pic']['large']).group(1)
                    imgheader = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.67',
                        'Referer': 'https://movie.douban.com/photos/photo/{}/'.format(imgcode)

                    }
                    cover = get_proxy_url(Spideryingshi.__name__, self.proxy_cover.__name__, {'url': imgurl, 'headers': imgheader})
                    name = video['title'].strip()
                    if '电影' in idname:
                        remark = video['rating']['value']
                        if remark != '':
                            remark = '{}分'.format(remark)
                        else:
                            remark = '暂无评分'
                    else:
                        remark = video['episodes_info']
                        if remark == '' and video['rating'] != None:
                            remark = video['rating']['value']
                            if remark != '':
                                remark = '{}分'.format(remark)
                        else:
                            remark = '暂无评分'
                    desc = '信息：{}\n简介：{}'.format(remark, remove_html_tags((voddesc).strip()))
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Search,
                            name=remove_html_tags(name).strip(),
                            id=vid,
                            description=desc,
                            cover=cover,
                            params={
                                'pf': 'db'
                            },
                        ))
                if page * 30 < data['total']:
                    has_next_page = True
                else:
                    has_next_page = False
                return items, has_next_page
            else:
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
        elif parent_item['params']['type'] == 'video':
            regex_url = re.compile(r'https://www.aliyundrive.com/s/[^"]+')
            if parent_item['params']['pf'] == 'qq':
                ts = int(time.time())
                params = {
                    'pcode': '010110002',
                    'version': '2.1.6',
                    'devid': hashlib.md5(str(time.time()).encode()).hexdigest(),
                    'package': 'com.sevenVideo.app.android',
                    'sys': 'android',
                    'sysver': 13,
                    'brand': 'Redmi',
                    'model': 'M2104K10AC'
                }
                params['ids'] = parent_item['id']
                params['sj'] = ts
                headers = {
                    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 12; M2104K10AC Build/SP1A.210812.016)'
                }
                headers['t'] = str(ts)
                url = 'http://api.tyun77.cn/api.php/provide/videoDetail'
                headers['TK'] = self.get_tk(url, params, ts)
                r = requests.get(url, params=params, headers=headers, timeout=5)
                result = json.loads(cleanText(r.text))
                if result['code'] == 1:
                    detail = result['data']
                else:
                    r = requests.get('http://api.tyun77.cn/api.php/provide/getDomain', params=params, headers=headers, timeout=5)
                    if r.json()['code'] == 1:
                        r = requests.get(url, params=params, headers=headers, timeout=5)
                        detail = json.loads(cleanText(r.text))['data']
                    else:
                        xbmcgui.Dialog().notification('提示', '无可播放内容', get_image_path('yingshi.png'), 5000, False)
                        sys.exit()
                url = 'http://api.tyun77.cn/api.php/provide/videoPlaylist'
                headers['TK'] = self.get_tk(url, params, ts)
                r = requests.get(url, params=params, headers=headers, timeout=5)
                result = json.loads(cleanText(r.text))
                if result['code'] == 1:
                    episodes = result['data']['episodes']
                else:
                    r = requests.get('http://api.tyun77.cn/api.php/provide/getDomain', params=params, headers=headers, timeout=5)
                    if r.json()['code'] == 1:
                        r = requests.get(url, params=params, headers=headers, timeout=5)
                        episodes = json.loads(cleanText(r.text))['data']['episodes']
                    else:
                        xbmcgui.Dialog().notification('提示', '无可播放内容', get_image_path('yingshi.png'), 5000, False)
                        sys.exit()
                items = []
                for episode in episodes:
                    sources = []
                    danmakus = []
                    for playurl in episode['playurls']:
                        if playurl['playfrom'] == 'alivc':
                            continue
                        sources.append(
                            SpiderSource(
                                playurl['playfrom'],
                                {
                                    'playfrom': playurl['playfrom'],
                                    'url': playurl['playurl'],
                                    'pf': 'qq'
                                },
                            ))
                        if playurl['playfrom'] in ['qq', 'mgtv', 'qiyi', 'youku', 'bilibili']:
                            if playurl['playfrom'] != 'bilibili':
                                danmu = playurl['playurl']
                            else:
                                r = requests.get(url=playurl['playurl'], headers=headers, timeout=5)
                                m = re.search(r'"cid":(.*?),', cleanText(r.text))
                                oid = m.group(1)
                                if not oid or oid == '0':
                                    m = re.search(r'bilivideo.com/upgcxcode/\d+/\d+(?:/(\d+)){2}', cleanText(r.text))
                                    oid = m.group(1)
                                danmu = 'bilibilidanmu' +oid
                            danmakus.append(
                                SpiderDanmaku(
                                    playurl['playfrom'],
                                    get_danmaku_url(danmu),
                                )
                            )
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=remove_html_tags(episode['title']).strip(),
                            cover=detail['videoCover'],
                            description=remove_html_tags(detail['brief']).replace('\u3000', '').strip(),
                            cast=detail['actor'].replace(' ', '').split('/'),
                            director=detail['director'],
                            area=detail['area'].strip(),
                            year=int(detail['year'].strip()),
                            sources=sources,
                            danmakus=danmakus,
                            params={
                                'speedtest': spLimit,
                                'thlimit': thlimit,
                            }
                        ))
                return items, False
            elif parent_item['params']['pf'] == 'cz':
                url = parent_item['params']['url']
                header = {
                    'Origin': 'https://czzy.fun/',
                    'Referer': 'https://czzy.fun/',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36',
                    'Cookie': 'esc_search_captcha=1'
                }
                r = requests.get(url, headers=header, timeout=5)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = soup.select('div.dyimg > img')[0].get('src')
                description = soup.select('div.yp_context')[0].text.strip().replace('\t\t', '')
                area = ''
                year = 0
                director = ''
                cast = []
                for e in soup.select('ul.moviedteail_list > li'):
                    info = e.text.strip()
                    if len(info) < 4:
                        continue
                    key = info[:2]
                    value = info[3:]
                    if key == '地区':
                        area = value
                    elif key == '年份':
                        try:
                            year = int(value)
                        except:
                            pass
                    elif key == '导演':
                        director = value
                    elif key == '主演':
                        cast = value.split(' ')

                items = []
                for a in soup.select('div.paly_list_btn > a'):
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=a.text.strip(),
                            cover=cover,
                            description=description,
                            cast=cast,
                            director=director,
                            area=area,
                            year=year,
                            sources=[
                                SpiderSource(
                                    'czspp',
                                    {
                                        'url': a.get('href'),
                                        'playfrom': '',
                                        'pf': 'cz',
                                    },
                                )
                            ],
                        ))
                return items, False
            elif parent_item['params']['pf'] == 'T4':
                items = []
                header = {"User-Agent": "okhttp/3.12.11"}
                url = '{}?ac=detail&ids={}'.format(parent_item['params']['api'], parent_item['id'])
                try:
                    r = requests.get(url, headers=header, timeout=5)
                    if r.status_code != 200:
                        header = {
                            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
                        r = requests.get(url, headers=header, timeout=5)
                    jo = json.loads(cleanText(r.text))['list'][0]
                except:
                    xbmcgui.Dialog().notification('提示', '无可播放内容', get_image_path('yingshi.png'), 5000, False)
                    sys.exit()
                cover = jo['vod_pic']
                desc = remove_html_tags(jo['vod_content']).replace('\r', '').replace('&nbsp; ','').replace('\u3000','').strip()
                episinfos = jo['vod_play_url'].strip('$$$').split('$$$')
                numepis = []
                episList = []
                titleInfos = []
                titleList = jo['vod_play_from'].strip('$$$').split('$$$')
                i = 0
                for episinfo in episinfos:
                    lennp = len(episinfo.strip('#').split('#'))
                    numepis.append(lennp)
                    episList.append(episinfo.strip('#').split('#'))
                    titleInfos.append([lennp, titleList[i].strip()])
                    i = i + 1
                episList.sort(key=lambda i: len(i), reverse=True)
                titleInfos.sort(key=lambda i: i[0], reverse=True)
                maxepis = max(numepis)
                episodes = episList[0]
                a = 0
                b = 0
                for episode in episodes:
                    sources = []
                    i = 0
                    name = episode.strip('$').split('$')[0].strip()
                    for epis in episList:
                        if i == 0:
                            k = a
                        else:
                            k = b
                        if k >= len(epis):
                            continue
                        if epis[k] == episode:
                            sepisode = episode
                        else:
                            sepisode = epis[b]
                        title = titleInfos[i][1]
                        sname = sepisode.strip('$').split('$')[0].strip()
                        if len(sepisode) == maxepis or '1080P' in sname or 'HD' in sname or '正片' in sname or '国语' in sname or '粤语' in sname or '韩语' in sname or '英语' in sname or '中字' in sname:
                            ratio = 1
                        else:
                            n = re.search(r'(\d+)', name)
                            if n:
                                n = int(n.group(1))
                            else:
                                n = name
                            s = re.search(r'(\d+)', sname)
                            if s:
                                s = int(s.group(1))
                            else:
                                s = sname
                            ratio = difflib.SequenceMatcher(None, str(n), str(s)).ratio()
                        if ratio < 0.1 or '预告' in sname or '回顾' in sname:
                            b = b - 1
                            continue
                        purl = sepisode.strip('$').split('$')[1].strip()
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': title,
                                    'pf': 'T4',
                                    'url': purl,
                                    'api': parent_item['params']['api']
                                },
                            ))
                        i = i + 1
                    a = a + 1
                    b = b + 1
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=remove_html_tags(name).strip(),
                            cover=cover,
                            description=desc,
                            sources=sources,
                            params={
                                'speedtest': spLimit,
                                'thlimit': thlimit,
                            }
                        ))
                return items, False
            elif parent_item['params']['pf'] == 'ps':
                if not parent_item['id'].startswith('http'):
                    header = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
                        'Referer': 'https://www.alipansou.com' + '/s/' + parent_item['id']
                    }
                    r = requests.get('https://www.alipansou.com' + '/cv/' + parent_item['id'], allow_redirects=False, headers=header, timeout=5)
                    m = regex_url.search(cleanText(r.text))
                    url = m.group().replace('\\', '')
                    parent_item['id'] = url
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
            elif parent_item['params']['pf'] == 'wogg':
                if not 'www.aliyundrive.com' in parent_item['id']:
                    url = 'http://wogg.xyz/index.php/voddetail/{}.html'.format(parent_item['id'])
                    r = requests.get(url, timeout=5)
                    m = regex_url.search(cleanText(r.text))
                else:
                    m = regex_url.search(parent_item['id'])
                parent_item['id'] = m.group().replace('\\', '')
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
            elif parent_item['params']['pf'] in ['qy', 'yp', 'ali']:
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
            elif bbexists is True and parent_item['params']['pf'] == '影视':
                return Spiderbilibili.list_items(Spiderbilibili(), parent_item, page)
            else:
                return [], False
        else:
            return [], False

    def resolve_play_url(self, source_params):
        if not source_params['pf'] in ['cz', 'ali', '影视']:
            return SpiderPlayURL(source_params['url'])
        elif source_params['pf'] == 'cz':
            url = source_params['url']
            header = {
                'Origin': 'https://czzy.fun/',
                'Referer': 'https://czzy.fun/',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36',
                'Cookie': 'esc_search_captcha=1'
            }
            r = requests.get(url, headers=header, timeout=5)
            m = re.search(
                r'\"([^\"]+)\";var [\d\w]+=function dncry.*md5.enc.Utf8.parse\(\"([\d\w]+)\".*md5.enc.Utf8.parse\(([\d]+)\)',
                r.text,
            )
            if m:
                b64 = m.group(1)
                key = m.group(2).encode()
                iv = m.group(3).encode()
                enc = base64.b64decode(b64)
                cipher = AES(key)
                padded_data = cipher.decrypt_cbc(enc, iv)
                data = padded_data[:-padded_data[-1]].decode()
                play_url = ''
                m = re.search(r'video: *\{url: *\"([^\"]+)\"', data)
                if m:
                    play_url = m.group(1)
                    if play_url.endswith('.m3u8'):
                        tspList = self.readM3U8(play_url, {}, 'cz')
                        play_url = get_proxy_url(Spideryingshi.__name__, self.proxy_m3u8.__name__, {'url': tspList[1], 'headers': {}, 'proxy': tspList[2], 'adrules': adrules})
                subtitles = []
                m = re.search(r'subtitle: *\{url: *\"([^\"]+)\"', data)
                if m:
                    subtitles.append(SpiderSubtitle('czspp', m.group(1)))
                return SpiderPlayURL(play_url, subtitles=subtitles)
            else:
                url = re.search(r'<iframe.*?src=\"(.*?)\".*?</iframe>', r.text).group(1)
                r = requests.get(url, headers=header, timeout=5)
                m = re.search(r'var rand = \"(.*?)\".*var player = \"(.*?)\"', r.text.replace('\n', ''))
                if m:
                    b64 = m.group(2)
                    iv = m.group(1)
                    enc = base64.b64decode(b64)
                    cipher = AES('VFBTzdujpR9FWBhe'.encode())
                    data = cipher.decrypt_cbc(enc, iv.encode())
                    return SpiderPlayURL(json.loads(data)['url'])
                xbmcgui.Dialog().notification('提示', '非厂长自压片源，请自行寻找其他片源观看', get_image_path('yingshi.png'), 5000, False)
                sys.exit()
        elif source_params['pf'] == 'ali':
            return SpiderAliyunDrive.resolve_play_url(SpiderAliyunDrive(), source_params)
        elif bbexists is True and source_params['pf'] == '影视':
            return Spiderbilibili.resolve_play_url(Spiderbilibili(), source_params)
        else:
            sys.exit()

    def checkPurl(self, source_params, tag):
        try:
            if source_params['pf'] == 'qq':
                headers = {}
                qqurl = source_params['url']
                if 'QiQi' in jdata and 'jx' in jdata['QiQi'][0] and 'gs' in jdata['QiQi'][0] and 'erro' in \
                        jdata['QiQi'][0]:
                    jxinfos = jdata['QiQi']
                    for jxinfo in jxinfos:
                        jx = jxinfo['jx']
                        if '{}' in jx:
                            if 'info' in dir():
                                jx = jx.format(info)
                            else:
                                parse = urlparse(jx)
                                parseinfos = parse.path.strip('/').split('/')
                                url = '{}://{}/config/{}/{}/0'.format(parse.scheme, parse.netloc, parseinfos[2],
                                                                      parseinfos[3])
                                r = requests.get(url, timeout=5)
                                jo = json.loads(cleanText(r.text).replace('/*', '').replace('*/', ''))['sites']
                                for j in jo:
                                    if parse.netloc in j['api']:
                                        parse = urlparse(j['api'])
                                        parseinfos = parse.path.strip('/').split('/')
                                        info = parseinfos[0]
                                        jx = jx.format(info)
                                        break
                        gs = jxinfo['gs'].strip().split(',')
                        erro = jxinfo['erro']
                        jurl = jx + qqurl
                        if 'header' in jxinfo:
                            headers = {"User-Agent": jxinfo['header']}
                        r = requests.get(jurl, headers=headers, timeout=5)
                        if erro in cleanText(r.text) and erro != '':
                            continue
                        qqurl = json.loads(cleanText(r.text))
                        for i in range(0, len(gs)):
                            qqurl = qqurl[gs[i]]
                        if qqurl != '':
                            break
                    if qqurl == source_params['url']:
                        return [{tag: 0}, '']
                else:
                    return [{tag: 0}, '']

                tspList = self.readM3U8(qqurl, headers, tag)
                purl = get_proxy_url(Spideryingshi.__name__, self.proxy_m3u8.__name__, {'url': tspList[1], 'headers': headers, 'proxy': tspList[2], 'adrules': adrules})
                return [tspList[0], purl]
            elif source_params['pf'] == 'T4':
                header = {"User-Agent": "okhttp/3.12.11"}
                if 'http://' in source_params['url'] or 'https://' in source_params['url']:
                    purl = source_params['url']
                else:
                    if '?proxy=' not in source_params['api']:
                        url = '{}?play={}&flag={}'.format(source_params['api'], source_params['url'], source_params['playfrom'])
                    else:
                        url = '{}&play={}&flag={}'.format(source_params['api'], source_params['url'], source_params['playfrom'])
                    r = requests.get(url, headers=header, timeout=5)
                    jo = json.loads(cleanText(r.text))
                    purl = jo['url']
                    if 'jx' in jo and jo['jx'] == '1':
                        if '://v.qq.com/' in purl or '://v.youku.com/' in purl or '://www.mgtv.com/' in purl or '://www.iqiyi.com/' in purl:
                            tag = tag + "@@@" + jo['url']
                        elif '://www.bilibili.com/' in purl:
                            r = requests.get(url=purl, headers=header, timeout=5)
                            m = re.search(r'"cid":(.*?),', cleanText(r.text))
                            oid = m.group(1)
                            if not oid or oid == '0':
                                m = re.search(r'bilivideo.com/upgcxcode/\d+/\d+(?:/(\d+)){2}', cleanText(r.text))
                                oid = m.group(1)
                            danmu = 'bilibilidanmu' + oid
                            tag = tag + "@@@" + danmu
                        if 'QiQi' in jdata:
                            jxinfos = jdata['QiQi']
                            for jxinfo in jxinfos:
                                if 'jx' not in jxinfo or 'gs' not in jxinfo or 'erro' not in jxinfo:
                                    continue
                                jx = jxinfo['jx']
                                if '{}' in jx:
                                    parse = urlparse(source_params['api'])
                                    parseinfos = parse.path.strip('/').split('/')
                                    jx = jx.format(parseinfos[0])
                                gs = jxinfo['gs'].strip().split(',')
                                erro = jxinfo['erro']
                                jurl = jx + jo['url']
                                if 'header' in jxinfo:
                                    header = {"User-Agent": jxinfo['header']}
                                r = requests.get(jurl, headers=header, timeout=5)
                                if erro in cleanText(r.text) and erro != '':
                                    continue
                                purl = json.loads(cleanText(r.text))
                                for i in range(0, len(gs)):
                                    purl = purl[gs[i]]
                                if purl != '':
                                    break
                tspList = self.readM3U8(purl, header, tag)
                purl = get_proxy_url(Spideryingshi.__name__, self.proxy_m3u8.__name__, {'url': tspList[1], 'headers': header, 'proxy': tspList[2], 'adrules': adrules})
                return [tspList[0], purl]
            else:
                return [{tag: 0}, '']
        except:
            return [{tag: 0}, '']

    def readM3U8(self, url, header, tag):
        if url.startswith('data:application'):
            try:
                set_cache('base64content', url)
                m3u8List = base64.b64decode(url.split('base64,')[1].encode()).decode().splitlines()
                ts_url = ''
                ts_num = len(m3u8List) - 1
                while ts_url == '':
                    if m3u8List[ts_num].startswith('http') and '.key' not in m3u8List[ts_num]:
                        ts_url = m3u8List[ts_num]
                    else:
                        ts_num -= 1
                return self.SpeedInfo(ts_url, header, tag, 'base64content')
            except:
                return {tag: 0}
        url = url.strip('/')
        BWDict = {}
        m3u8List = []
        try:
            r = requests.get(url, headers=header, stream=True, allow_redirects=False, verify=False, timeout=5)
            if 'Content-Type' in r.headers and 'video' in r.headers['Content-Type']:
                r.close()
                return  self.SpeedInfo(url, header, tag, url)
            elif 'Location' in r.headers and '#EXTM3U' not in r.text:
                r.close()
                url = r.headers['Location']
                r = requests.get(url, headers=header, stream=True, allow_redirects=False, verify=False, timeout=5)
            for line in r.iter_lines(8096):
                line = line.decode('utf-8', 'ignore')
                if len(line) > 0 and not line.startswith('#'):
                    if not line.startswith('http'):
                        if line.startswith('/'):
                            line = url[:url.index('/', 8)] + line
                        else:
                            line = url[:url.rindex('/') + 1] + line
                m3u8List.append(line)
                if 'BANDWIDTH' in line:
                    BW = int(re.search(r'BANDWIDTH=(\d+)', line).group(1))
                    BWPOS = m3u8List.index(line)
                    BWDict.update({BW: BWPOS})
            r.close()
            if len(BWDict) > 0:
                m3u8_url = m3u8List[BWDict[max(BWDict.keys())] + 1]
                return self.readM3U8(m3u8_url, header, tag)
            ts_url = ''
            ts_num = len(m3u8List) - 1
            while ts_url == '':
                if m3u8List[ts_num].startswith('http') and '.key' not in m3u8List[ts_num]:
                    ts_url = m3u8List[ts_num]
                else:
                    ts_num -= 1
            return self.SpeedInfo(ts_url, header, tag, url)
        except:
            try:
                r.close()
            except:
                pass
            return {tag: 0}

    def SpeedInfo(self, url, header, tag, purl):
        r = requests.get(url, stream=True, headers=header, verify=False, timeout=5)
        count = 0
        count_tmp = 0
        stime = time.time()
        i = 0
        speed = 0
        proxy = 'nomral'
        for chunk in r.iter_content(chunk_size=40960):
            if chunk:
                if i == 2:
                    break
                count += len(chunk)
                sptime = time.time() - stime
                if chunk.startswith(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46') or chunk.startswith(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A') or chunk.startswith(b'\x42\x4D') or chunk.startswith(b'\x47\x49\x46\x38') or chunk.startswith(b'\x4D\x4D') or chunk.startswith(b'\x49\x49') or chunk.startswith(b'\x00\x00\x01\x00') or chunk.startswith(b'\x47'):
                    proxy = 'proxy'
                if count == int(r.headers['content-length']):
                    if sptime > 0:
                        speed = int((count - count_tmp) / sptime)
                    else:
                        speed = 1572864
                if sptime > 0:
                    speed = int((count - count_tmp)/sptime)
                    stime = time.time()
                    count_tmp = count
                    i = i + 1
        try:
            r.close()
        except:
            pass
        return [{tag: speed}, purl, proxy]

    def search(self, keyword, page=1):
        items = []
        if 'YSDQ' in jdata and 'searchList' in jdata['YSDQ']:
            strsws = jdata['YSDQ']['searchList'].strip().strip(',').strip('\n')
        else:
            strsws ="qq,cz,bb,wogg,qy,ps,yp"
        if 'YSDQ' in jdata and 'T4api' in jdata['YSDQ']:
            T4List = jdata['YSDQ']['T4api']
        if 'YSDQ' in jdata and 'CJapi' in jdata['YSDQ']:
            CJList = jdata['YSDQ']['CJapi']
        if page > 1:
            strsws = get_cache('strsws')
            del_cache('strsws')
        sws = strsws.split(',')
        if 'T4List' in dir() and page == 1:
            sws = T4List + sws
        if 'CJList' in dir() and page == 1:
            sws = CJList + sws
        if bbhide is True or bbexists is False:
            if 'bb' in sws:
                sws.remove('bb')
        contents = []
        keyword = keyword.replace('/', '%2F')
        with concurrent.futures.ThreadPoolExecutor(max_workers=thlimit) as executor:
            searchList = []
            try:
                for sw in sws:
                    num = sws.index(sw)
                    if type(sw) is dict:
                        tag = 'T4'
                        api = '{}@@@{}'.format(sw['name'], sw['api'])
                    else:
                        tag = sw
                        api = ''
                    future = executor.submit(self.runSearch, keyword, tag, page, num, api)
                    searchList.append(future)
                for future in concurrent.futures.as_completed(searchList, timeout=30):  # 并发执行
                    contents.append(future.result())
            except:
                executor.shutdown(wait=False)
        nextpageList = []
        for content in contents:
            key = list(content.keys())[0]
            infos = content[key]
            items = items + content[key][0]
            nextpageList.append(infos[1])
            if not infos[1]:
                strsws = strsws.replace(key, '').replace(',,', ',').strip(',')
        if True in nextpageList:
            has_next_page = True
        else:
            has_next_page = False
        set_cache('strsws',strsws)
        items.sort(key=lambda i: i['params']['num'], reverse=False)
        return items, has_next_page

    def runSearch(self, keyword, tag, page, num, api):
        try:
            funList = dir(Spideryingshi)
            defname = 'self.search' + tag
            if defname.replace('self.', '') in funList and tag != '':
                result = eval(defname)(keyword, tag, page, num, api)
            return result
        except:
            return {tag: [[], False]}

    def searchqq(self, keyword, tag, page, num, api):
        items = []
        url = 'http://api.tyun77.cn/api.php/provide/searchVideo'
        ts = int(time.time())
        params = {
            'pcode': '010110002',
            'version': '2.1.6',
            'devid': hashlib.md5(str(time.time()).encode()).hexdigest(),
            'package': 'com.sevenVideo.app.android',
            'sys': 'android',
            'sysver': 13,
            'brand': 'Redmi',
            'model': 'M2104K10AC'
        }
        params['sj'] = ts
        params['searchName'] = keyword
        params['pg'] = page
        headers = {
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 12; M2104K10AC Build/SP1A.210812.016)'
        }
        headers['t'] = str(ts)
        headers['TK'] = self.get_tk(url, params, ts)
        r = requests.get(url, params=params, headers=headers, timeout=5)
        jo = json.loads(cleanText(r.text))
        data = jo['data']
        if len(data) == 20:
            nexpage = True
        else:
            nexpage = False
        for video in data:
            remark = video['msg'].strip()
            if remark == '':
                remark = 'HD'
            voddesc = remove_html_tags(video['brief']).replace('\r', '').replace('&nbsp; ','').replace('\u3000','').strip()
            desc = '信息：{}\n简介：{}'.format(remark.strip(), voddesc)
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='七七：{}'.format(remove_html_tags(video['videoName']).strip()),
                    id=video['id'],
                    cover=video['videoCover'],
                    description=desc,
                    cast=video['starName'].replace(' ','').replace('声优','').replace(':',',').replace('：',',').replace(' ',',').strip(',').split(','),
                    params={
                        'type': 'video',
                        'pf': 'qq',
                        'num': num
                    },
                ))
        return {tag: [items, nexpage]}

    def searchcz(self, keyword, tag, page, num, api):
        items = []
        has_next_page = False
        header = {
            'Origin': 'https://czzy.fun/',
            'Referer': 'https://czzy.fun/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36',
            'Cookie': 'esc_search_captcha=1'
        }
        r = requests.post('https://czzy.fun/page/{}'.format(page), headers=header, params={'s': keyword}, timeout=5)
        soup = BeautifulSoup(r.text, 'html.parser')
        mdict = dict.fromkeys(string.punctuation)
        mdict[' '] = None
        mdict['：'] = None
        table = str.maketrans(mdict)
        for e in soup.select('div.mi_ne_kd > ul > li'):
            name = e.select('img')[0].get('alt').strip()
            if keyword.translate(table) not in name.translate(table):
                continue
            descList = [i.strip() for i in e.get_text().strip().split('\n') if i.strip()]
            desc = ''
            for des in descList:
                desc = desc + des + '\n'
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id=re.search(
                        r'/(\d+)\.html',
                        e.select('a')[0].get('href'),
                    ).group(1),
                    name='厂长：{}'.format(name),
                    cover=e.select('img')[0].get('data-original'),
                    description=desc,
                    params={
                        'type': 'video',
                        'url': e.select('a')[0].get('href'),
                        'pf': 'cz',
                        'num': num
                    },
                ))
        max_page = soup.select('div.pagenavi_txt > a')
        if max_page != []:
            max_page = max_page[-1].get('href')
            max_page = re.findall(r'\d+', max_page)
            max_page = int(max_page[-1])
            if page < max_page:
                has_next_page = True
        return {tag: [items, has_next_page]}

    def searchT4(self, keyword, tag, page, num, api):
        items = []
        header = {"User-Agent": "okhttp/3.12.11"}
        apis = api.split('@@@')
        tag = apis[0]
        api = apis[1].strip('/')
        if '?proxy=' not in apis[1]:
            api = apis[1].strip('/')
            url = '{}?wd={}&ac=detail'.format(api, urllib.parse.quote(keyword))
        else:
            api = apis[1]
            url = '{}&wd={}&ac=detail'.format(api, urllib.parse.quote(keyword))
        r = requests.get(url, headers=header, timeout=5)
        if r.status_code != 200:
            header = {
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
            r = requests.get(url, headers=header, timeout=5)
        jo = json.loads(cleanText(r.text))
        vodList = jo['list']
        for vod in vodList:
            aid = vod['vod_id']
            title = vod['vod_name'].strip()
            if difflib.SequenceMatcher(None, title, keyword).ratio() < 0.6 and keyword not in title:
                continue
            img = vod['vod_pic']
            desc = remove_html_tags(vod['vod_remarks']).strip()
            if desc == '':
                desc = 'HD'
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='{}：{}'.format(tag, title),
                    id=aid,
                    description='信息：' + desc,
                    cover=img,
                    params={
                        'type': 'video',
                        'pf': 'T4',
                        'api': api,
                        'num': num
                    },
                ))

        return {tag: [items, False]}

    def searchbb(self, keyword, tag, page, num, api):
        items = []
        url = 'https://api.bilibili.com/x/web-interface/search/type?search_type=media_bangumi&keyword={0}'.format(keyword)
        if not hasattr(self, 'bbck'):
            cookie = self.getCookie('bb')
        else:
            cookie = self.bbck
        r = requests.get(url, cookies=cookie, timeout=5)
        jo = json.loads(cleanText(r.text))
        if jo['data']['numResults'] != 0:
            vodList = jo['data']['result']
            for vod in vodList:
                aid = str(vod['season_id']).strip()
                title = remove_html_tags(vod['title']).strip()
                img = vod['eps'][0]['cover'].strip()
                desc = remove_html_tags(vod['index_show']).strip()
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        name='哔哩影视：{}'.format(title),
                        id=aid,
                        description='信息：' + desc,
                        cover=img,
                        params={
                            'type': 'video',
                            'pf': '影视',
                            'num': num
                        },
                    ))
        return {tag: [items, False]}

    def searchwogg(self, keyword, tag, page, num, api):
        items = []
        url = 'http://wogg.xyz/index.php/vodsearch/{}----------{}---.html'.format(keyword, page)
        r = requests.get(url, verify=False, timeout=5)
        soup = BeautifulSoup(cleanText(r.text), 'html.parser')
        datas = soup.select('div.module-items > div')
        nextpage = True
        for data in datas:
            img = data.find('img').get('data-src')
            if not img.startswith('http'):
                img = 'http://wogg.xyz' + img
            title = data.find('img').get('alt').strip()
            aid = data.select('div.video-info-footer > a')[0].get('href')
            aid = re.search(r'/(\d+)\.html', aid).group(1)
            desc = remove_html_tags(data.select('div.video-info-items > div.video-info-item')[-1].get_text()).strip()
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='阿里玩偶：{}'.format(title),
                    id=aid,
                    description='信息：' + desc,
                    cover=img,
                    params={
                        'type': 'video',
                        'pf': 'wogg',
                        'num': num
                    },
                ))

        maxpage = soup.select('div#page > a')
        if maxpage != []:
            maxpage = maxpage[-1].get('href')
            maxpage = re.search(r'-(\d+)-', maxpage).group(1)
            if page == int(maxpage):
                nextpage = False
        else:
            nextpage = False
        return {tag: [items, nextpage]}

    def searchqy(self, keyword, tag, page, num, api):
        items = []
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.37"
        }
        r = requests.get('https://api.dovx.tk/ali/search?wd={}'.format(keyword), headers=header, timeout=5)
        vList = r.json()['list']
        for video in vList:
            vid = video['vod_content']
            if 'www.aliyundrive.com' not in vid:
                continue
            name = video['vod_name']
            if len(name) > len(keyword) + 20:
                name = ''.join(OrderedDict.fromkeys(name))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id=vid,
                    name='七夜：' + name,
                    cover=video['vod_pic'],
                    params={
                        'type': 'video',
                        'pf': 'qy',
                        'num': num
                    }
                ))
        return {tag: [items, False]}

    def searchps(self, keyword, tag, page, num, api):
        items = []
        has_next_page = False
        r = requests.get('https://www.alipansou.com/search', params={'page': page, 'k': keyword, 't': 7}, timeout=5)
        soup = BeautifulSoup(cleanText(r.text), 'html.parser')
        rows = soup.select('van-row > a')
        for row in rows:
            desc = re.search(r'时间: (.*?) ', str(row.get_text)).group(1)
            clean = re.compile('<.*?>')
            name = re.sub(clean, '', row.find('template').__str__()).replace('\n', '').replace('\t', '').replace(' ', '')
            if name.count(keyword) > 1 or len(name)-len(keyword) > 10:
                name = ''.join(OrderedDict.fromkeys(name))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='阿里盘搜：{}'.format(remove_html_tags(name).strip()),
                    description='更新时间：' + remove_html_tags(desc).strip(),
                    id=re.search(r'/s/(.*)', row.get('href')).group(1),
                    params={
                        'type': 'video',
                        'pf': 'ps',
                        'num': num
                    }
                ))
        max_page = soup.select('van-row > van-col > van-pagination')[0].get('page-count')
        if page < int(max_page):
            has_next_page = True
        return {tag: [items, has_next_page]}

    def searchyp(self, keyword, tag, page, num, api):
        items = []
        header = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 12; V2049A Build/SP1A.210812.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36",
            "Content-Type": "application/json"
        }
        has_next_page = False
        url = "https://pan.ccof.cc/api/search"
        param = {"pageSize":20,"pageNum": page,"keyword": keyword, "fromMobile":'true'}
        r = requests.post(url, headers=header, json=param, timeout=5)
        rows = r.json()
        fileidList = []
        shareidList = []
        regex_share_id = re.compile(r'www.aliyundrive.com\/s\/([^\/]+)(\/folder\/([^\/]+))?')
        for row in rows['data']['rows']:
            vid = row['url']
            share_id = regex_share_id.search(vid).group(1)
            file_id = regex_share_id.search(vid).group(3)
            if share_id in shareidList or file_id in fileidList:
                continue
            fileidList.append(file_id)
            shareidList.append(share_id)
            name = row['fileName']
            if difflib.SequenceMatcher(None, name, keyword).ratio() < 0.6 and keyword not in name:
                continue
            if name.count(keyword) > 1 or len(name) - len(keyword) > 10:
                name = ''.join(OrderedDict.fromkeys(name))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id=vid,
                    name='阿里亚盘：{}'.format(remove_html_tags(name).strip()),
                    params={
                        'type': 'video',
                        'pf': 'yp',
                        'num': num
                    }
                ))
        max_page = rows['data']['count']
        if page * 20 < max_page:
            has_next_page = True
        return {tag: [items, has_next_page]}

    def getCookie(self, tag):
        if tag =='bb':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36"
            }
            r = requests.get("https://www.bilibili.com/", headers=header, timeout=5)
            self.bbck = r.cookies
            return r.cookies

    def getDanm(self, oid):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36"
        }
        r = requests.get('https://api.bilibili.com/x/v1/dm/list.so', params={'oid': oid}, headers=header, timeout=5)
        danmu = re.search(r'<?xml version.*?</source>(.*)</i>', r.content.decode())
        if danmu:
            danmu = danmu.group(1)
        else:
            danmu = ''
        set_cache('bilibilidanmu' + oid, danmu)
        return danmu

    def verifyCode(self, imgurl, resurl):
        if 'YSDQ' in jdata and 'ocrurl' in jdata['YSDQ']:
            ocrurl = jdata['YSDQ']['ocrurl']
        else:
            return False, None
        retry = 5
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"
        }
        try:
            session = requests.session()
            r = session.post(ocrurl, json={'url': imgurl}, timeout=5)
            jo = r.json()
            if jo['code'] == 1:
                code = jo['result']
                session.cookies.update(jo['cookies'])
            else:
                return False, None
            res = session.post(url="{}{}".format(resurl, code), headers=header, timeout=5).json()
            if res["msg"] == "ok":
                return True, session
        except:
            pass
        return False, None

    def get_tk(self, url, params, ts):
        keys = []
        for key in params:
            keys.append(key)
        keys.sort()
        src = urlparse(url).path
        for key in keys:
            src += str(params[key])
        src += str(ts)
        src += 'XSpeUFjJ'
        return hashlib.md5(src.encode()).hexdigest()

    def proxy_m3u8(self, ctx, params):
        url = params['url']
        headers = params['headers']
        adrules = params['adrules']
        if params['proxy'] == 'proxy':
            proxyinfos = {'spider': 'Spideryingshi', 'function': 'proxy_media', 'content_type': 'application/vnd.apple.mpegurl', 'adrules': adrules}
        else:
            proxyinfos = {'content_type': 'application/vnd.apple.mpegurl', 'adrules': adrules}
        self.proxy(ctx, url, headers, proxyinfos)

    def proxy_media(self, ctx, params):
        url = params['url']
        headers = params['headers']
        proxyinfos = params['proxyinfos']
        proxyinfos.update({'content_type': 'video/MP2T'})
        self.proxy(ctx, url, headers, proxyinfos)

    def proxy_cover(self, ctx, params):
        img = requests.get(params['url'], headers=params['headers'], timeout=5)
        ctx.send_response(200)
        ctx.send_header('Content-Type', img.headers['Content-Type'])
        ctx.end_headers()
        ctx.wfile.write(img.content)
