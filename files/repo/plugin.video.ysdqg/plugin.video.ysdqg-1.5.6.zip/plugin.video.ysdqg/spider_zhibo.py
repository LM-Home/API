from spider import Spider, SpiderItemType, SpiderItem, SpiderSource, SpiderPlayURL
import os
import re
import sys
import json
import time
import html
import random
import base64
import hashlib
import requests
import urllib.parse
import concurrent.futures
from bs4 import BeautifulSoup
from proxy import get_proxy_url
from cache import get_cache, set_cache, del_cache
from utils import get_image_path, remove_html_tags
import xbmcaddon
import xbmcgui
import xbmcvfs

_ADDON = xbmcaddon.Addon()

localpath = _ADDON.getSettingString('user_path')
if localpath == '':
    localurl = xbmcvfs.translatePath(os.path.join(_ADDON.getAddonInfo('path'), 'YSDQG.json'))
else:
    localurl = xbmcvfs.translatePath(os.path.join(localpath, 'YSDQG.json'))

#localurl = 'YSDQG.json'

try:
    with open(localurl, 'r', encoding='utf-8') as f:
        data = f.read()
    jdata = json.loads(data.strip('\n'))
except Exception:
    jdata = {}

if 'YSDQ' in jdata and 'speedLimit' in jdata['YSDQ']:
    spLimit = jdata['YSDQ']['speedLimit']
else:
    spLimit = '1K'
if 'YSDQ' in jdata and 'thlimit' in jdata['YSDQ']:
    thlimit = jdata['YSDQ']['thlimit']
else:
    thlimit = 5


class SpiderZhiBo(Spider):

    def name(self):
        return '直播'

    def set_post(self):
        return False

    def is_searchable(self):
        return True

    def logo(self):
        return get_image_path('zhibo.png')

    def hide(self):
        return not _ADDON.getSettingBool('data_source_zhibo_switch')

    def list_items(self, parent_item=None, page=1):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        if parent_item is None:
            items = []
            if 'Zhibo' in jdata and len(jdata['Zhibo']) != 0:
                for ids in jdata['Zhibo']:
                    name = ids['name']
                    pf = ids['pf']
                    id = ids['id']
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            id=id,
                            name=name,
                            params={
                                'type': 'category',
                                'pf': pf,
                            },
                        ))
            else:
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id='208',
                        name='斗鱼-一起看',
                        params={
                            'type': 'category',
                            'pf': 'douyu',
                        },
                    ))
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id="2135",
                        name='虎牙-一起看',
                        params={
                            'type': 'category',
                            'pf': 'huya',
                        },
                    ))
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id="sport",
                        name='体育-全部',
                        params={
                            'type': 'category',
                            'pf': 'sport',

                        },
                    ))
            return items, False
        elif parent_item['params']['type'] == 'category':
            pf = parent_item['params']['pf']
            id = parent_item['id']
            if pf == 'douyu':
                url = 'https://www.douyu.com/gapi/rkc/directory/mixList/2_{}/{}'.format(id, page)
                r = requests.get(url)
                data = r.json()
                items = []
                for room in data['data']['rl']:
                    if room['type'] != 1:
                        continue
                    items.append(
                        SpiderItem(type=SpiderItemType.File,
                                   id=room['rid'],
                                   name=room['rn'],
                                   description='主播：{}\n在线人数：{}'.format(room['nn'], room['ol']),
                                   cover=room['rs1'],
                                   sources=[
                                       SpiderSource(
                                           room['rid'],
                                           {
                                               'pf': pf,
                                               'id': room['rid'],
                                           },
                                       )
                                   ]))
                return items, page < data['data']['pgcnt']
            elif pf == 'huya':
                header = {
                    "Connection": "keep-alive",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                    'Referer': 'https://www.huya.com/'
                }
                url = 'https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId={0}&tagAll=0&callback=getLiveListJsonpCallback&page={1}'.format(
                    id, page)
                r = requests.get(url, headers=header)
                strjson = re.search(r"getLiveListJsonpCallback\((.*)\)", r.text).group(1)
                data = json.loads(strjson)
                items = []
                for room in data['data']['datas']:
                    items.append(
                        SpiderItem(type=SpiderItemType.Directory,
                                   id=room['profileRoom'],
                                   name=room['introduction'],
                                   description='主播：{}\n在线人数：{}'.format(room['nick'], room['totalCount']),
                                   cover=room['screenshot'],
                                   params={
                                       'type': 'video',
                                       'pf': pf,
                                   }
                                   ))
                return items, page < data['data']['totalPage']
            elif pf == 'bilibili':
                r = requests.get(
                    'https://api.live.bilibili.com/xlive/web-interface/v1/second/getList',
                    params={
                        'platform': 'web',
                        'parent_area_id': parent_item['id'],
                        'page': page,
                    })
                data = r.json()
                items = []
                for room in data['data']['list']:
                    items.append(
                        SpiderItem(type=SpiderItemType.File,
                                   id=room['roomid'],
                                   name=room['title'],
                                   description='主播：{}\n在线人数：{}'.format(room['uname'], room['online']),
                                   cover=room['cover'],
                                   sources=[
                                       SpiderSource(
                                           room['roomid'],
                                           {
                                               'pf': pf,
                                               'id': room['roomid'],
                                           },
                                       )
                                   ]))
                return items, data['data']['has_more']
            elif pf == 'sport':
                url = 'http://itiyu5.tv/spweb/schedule'
                r = requests.get(url=url, headers=header, allow_redirects=False)
                soup = BeautifulSoup(r.content.decode('utf-8'), 'html.parser')
                dataList = soup.select('div.fixtures > div.box ')
                dateList = soup.select('div.subhead')
                items = []
                for data in dataList:
                    pos = dataList.index(data)
                    for video in data.select('div.list > ul > li'):
                        infosList = video.select('div.team > div')
                        stime = video.select('p.name > span')[0].get_text().strip()
                        sdate = dateList[pos].get_text().split()[0].strip()
                        hour = stime.split(':')[0]
                        if int(hour) < 3:
                            sdate = sdate.replace(sdate[3:-1], str(int(sdate[3:-1]) - 1))
                            stime = str(21 + int(hour)) + ':' + stime.split(':')[1]
                        else:
                            hour = str(int(hour) - 2)
                            if len(hour) == 1:
                                hour = '0' + hour
                            stime = hour + ':' + stime.split(':')[1]
                        rid = video.select('p.btn > a')[0].get('href')
                        state = video.select('p.btn > a')[0].get_text().strip()
                        if len(infosList) != 2:
                            home = infosList[0].select('span')[0].get_text().strip()
                            away = infosList[2].select('span')[0].get_text().strip()
                            gtype = infosList[1].select('span')[0].get_text().strip()
                            cover = infosList[0].select('img')[0].get('src')
                            name = home + 'VS' + away
                        else:
                            cover = 'https://s1.ax1x.com/2022/10/07/x3NPUO.png'
                            gtype = infosList[0].get_text().strip()
                            name = infosList[1].get_text().strip()
                        desc = '开播时间：{}|{}\n赛事：{}'.format(sdate, stime, gtype)
                        if state != '已结束':
                            items.append(
                                SpiderItem(
                                    type=SpiderItemType.Directory,
                                    id=rid,
                                    name='[{}|{}]{}'.format(sdate, stime, name),
                                    cover=cover,
                                    description=desc,
                                    params={
                                        'type': 'video',
                                        'pf': pf,
                                    }
                                ))
                return items, False
            else:
                items = []
                for key in parent_item:
                    locals()['video_{}'.format(key)] = parent_item[key]
                locals()['video_params']['type'] = 'video'
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id=locals()['video_id'],
                        name=locals()['video_name'],
                        danmakus=locals()['video_danmakus'],
                        subtitles=locals()['video_subtitles'],
                        cover=locals()['video_cover'],
                        sources=locals()['video_sources'],
                        description=locals()['video_description'],
                        params=locals()['video_params']
                    ))
        elif parent_item['params']['type'] == 'video':
            items = []
            if parent_item['params']['pf'] == 'huya':
                url = 'https://www.huya.com/' + parent_item['id']
                header = {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36'
                }
                r = requests.get(url, headers=header)
                streamInfo = re.findall(r'stream: ([\s\S]*?)\n', r.text)
                if (len(streamInfo) > 0):
                    liveData = json.loads(streamInfo[0])
                else:
                    streamInfo = re.findall(r'"stream": "([\s\S]*?)"', r.text)
                    if (len(streamInfo) > 0):
                        liveDataBase64 = streamInfo[0]
                        liveData = json.loads(str(base64.b64decode(liveDataBase64), 'utf-8'))
                streamInfoList = liveData['data'][0]['gameStreamInfoList']
                sources = []
                for streamInfo in streamInfoList:
                    hls_url = streamInfo['sHlsUrl'] + '/' + streamInfo['sStreamName'] + '.' + streamInfo[
                        'sHlsUrlSuffix']
                    srcAntiCode = html.unescape(streamInfo['sHlsAntiCode'])
                    c = srcAntiCode.split('&')
                    c = [i for i in c if i != '']
                    n = {i.split('=')[0]: i.split('=')[1] for i in c}
                    fm = urllib.parse.unquote(n['fm'])
                    u = base64.b64decode(fm).decode('utf-8')
                    hash_prefix = u.split('_')[0]
                    ctype = n.get('ctype', '')
                    txyp = n.get('txyp', '')
                    fs = n.get('fs', '')
                    t = n.get('t', '')
                    seqid = str(int(time.time() * 1e3 + 1463993859134))
                    wsTime = hex(int(time.time()) + 3600).replace('0x', '')
                    hash = hashlib.md5('_'.join([hash_prefix, '1463993859134', streamInfo['sStreamName'], hashlib.md5(
                        (seqid + '|' + ctype + '|' + t).encode('utf-8')).hexdigest(), wsTime]).encode(
                        'utf-8')).hexdigest()
                    ratio = ''
                    purl = "{}?wsSecret={}&wsTime={}&seqid={}&ctype={}&ver=1&txyp={}&fs={}&ratio={}&u={}&t={}&sv=2107230339".format(
                        hls_url, hash, wsTime, seqid, ctype, txyp, fs, ratio, '1463993859134', t)
                    sources.append(
                        SpiderSource(
                            streamInfo['sCdnType'],
                            {
                                'url': purl,
                                'pf': parent_item['params']['pf']
                            },
                        ))
                items.append(
                    SpiderItem(type=SpiderItemType.File,
                               id=parent_item['id'],
                               name=parent_item['name'],
                               description=parent_item['description'],
                               cover=parent_item['cover'],
                               sources=sources,
                               params={
                                   'speedtest': spLimit,
                                   'thlimit': thlimit,
                               }
                               ))
            elif parent_item['params']['pf'] == 'sport':
                url = 'http://itiyu5.tv{}'.format(parent_item['id'])
                r = requests.get(url, headers=header, allow_redirects=False)
                urls = r.text.count('{}/vid/'.format(parent_item['id']))
                if urls == 0:
                    xbmcgui.Dialog().notification('提示', '比赛尚未开始', get_image_path('zhibo.png'), 5000, False)
                    sys.exit()
                sources = []
                for i in range(1, urls+1):
                    if i > 1:
                        url = 'http://itiyu5.tv{}/vid/{}'.format(parent_item['id'], i)
                        r = requests.get(url, headers=header, allow_redirects=False)
                    if 'vid/{}'.format(i) not in r.text:
                        xbmcgui.Dialog().notification('提示', '无法获取播放地址', get_image_path('zhibo.png'), 5000, False)
                        sys.exit()
                    purl = re.search(r"\'url\': \"(.*?)\"", r.text).group(1)
                    if purl == '':
                        header['Referer'] = 'https://v.stnye.cc/'
                        header['Connection'] = 'keep-alive'
                        try:
                            rid = re.search(r'config\.iurl = \"(.*?)\"', r.text).group(1)
                        except:
                            xbmcgui.Dialog().notification('提示', '无法获取播放地址', get_image_path('zhibo.png'), 5000, False)
                            sys.exit()
                        if 'm3u8' in rid:
                            purl = rid
                            if purl.count('http') != 1:
                                replstr = re.search(r'(http.*?)http', purl).group(1)
                                purl = purl.replace(replstr, '')
                        else:
                            session = requests.session()
                            rid = re.search(r'id=(.*)', rid).group(1)
                            r = session.get(
                                'https://info.zb.video.qq.com/?cmd=4&callback=jQuery36009789292726928915_{}&_={}'.format(
                                    int(time.time()), int(time.time()) + 1), headers=header, allow_redirects=False)
                            country = json.loads(r.text)['country']
                            province = json.loads(r.text)['province']
                            city = json.loads(r.text)['city']
                            ip = json.loads(r.text)['ip']
                            r = session.get('https://geo.yolll.com/geo', headers=header, allow_redirects=False)
                            cf_ua = json.loads(r.text)['ua']
                            cf_cc = json.loads(r.text)['ip']
                            cf_ip = json.loads(r.text)['cc']
                            rnd = round(random.random() * 100000)
                            param = {
                                'type': 'stream',
                                'id': rid,
                                'rnd': rnd,
                                'ip': ip,
                                'country': urllib.parse.quote(country),
                                'province': urllib.parse.quote(province),
                                'city': urllib.parse.quote(city),
                                'tx_ip': ip,
                                'tx_country': urllib.parse.quote(country),
                                'tx_province': urllib.parse.quote(province),
                                'tx_city': urllib.parse.quote(city),
                                'cf_ip': cf_ip,
                                'cf_cc': cf_cc,
                                'cf_ua': cf_ua,
                                'ref': 'nesting',
                                'ua': 'web',
                            }
                            r = session.post('https://cdn.dianshunxinxi.com/data/live.php', data=param, headers=header)
                            jo = json.loads(r.text)
                            if jo['status'] != 'success':
                                xbmcgui.Dialog().notification('提示', '无法获取播放地址', get_image_path('zhibo.png'),5000, False)
                                sys.exit()
                            else:
                                purl = base64.b64decode(urllib.parse.unquote(jo['playurl'])).decode('utf-8')
                                purl = base64.b64decode(purl).decode('utf-8')
                    if '.m3u8' in purl:
                        sources.append(SpiderSource(
                            str(i),
                            {
                                'url': purl,
                                'pf': parent_item['params']['pf']
                            }))
                items.append(
                    SpiderItem(type=SpiderItemType.File,
                               id=parent_item['id'],
                               name=parent_item['name'],
                               description=parent_item['description'],
                               cover=parent_item['cover'],
                               sources=sources,
                               params={
                                   'speedtest': spLimit,
                                   'thlimit': thlimit,
                               }
                               ))
            else:
                for key in parent_item:
                    locals()['video_{}'.format(key)] = parent_item[key]
                items.append(
                    SpiderItem(
                        type=SpiderItemType.File,
                        id=locals()['video_id'],
                        name=locals()['video_name'],
                        danmakus=locals()['video_danmakus'],
                        subtitles=locals()['video_subtitles'],
                        cover=locals()['video_cover'],
                        sources=locals()['video_sources'],
                        description=locals()['video_description'],
                        params=locals()['video_params']
                    ))
        return items, False

    def resolve_play_url(self, source_params):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        pf = source_params['pf']
        if pf == 'douyu':
            url = 'https://getplayurl.lmteam.repl.co/live?platform={}&rid={}'.format(pf, source_params['id'])
            r = requests.get(url, allow_redirects=False)
            if 'Location' in r.headers:
                purl = r.headers['Location']
            else:
                xbmcgui.Dialog().notification('提示', '无法获取播放地址', get_image_path('zhibo.png'), 5000, False)
                sys.exit()
            return SpiderPlayURL(purl)
        elif pf == 'huya':
            header = {
                "Connection": "keep-alive",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                'Referer': 'https://www.huya.com/'
            }
            purl = source_params['url']
            return SpiderPlayURL(
                get_proxy_url(
                    SpiderZhiBo.__name__,
                    self.proxy_media.__name__,
                    {
                        'url': purl,
                        'headers': header,
                    },
                ))
        elif pf == 'bilibili':
            r = requests.get('https://api.live.bilibili.com/room/v1/Room/get_info?room_id={}'.format(source_params['id']), headers=header)
            if r.json()['data']['live_status'] == 0:
                xbmcgui.Dialog().notification('提示', '直播尚未开始', get_image_path('zhibo.png'), 5000, False)
                sys.exit()
            url = 'https://api.live.bilibili.com/room/v1/Room/playUrl?cid={0}&qn=20000&platform=h5'.format(source_params['id'])
            r = requests.get(url=url, headers=header)
            data = r.json()['data']
            purl = data['durl'][0]['url']
            return SpiderPlayURL(purl)
        elif pf == 'sport':
            return SpiderPlayURL(source_params['url'])
        else:
            return SpiderPlayURL(source_params['id'])

    def proxy_media(self, ctx, params):
        url = params['url']
        headers = params['headers'].copy()
        self.proxy(ctx, url, headers)

    def search(self, keyword, page=1):
        items = []
        strsws = "bb,dy,hy"
        if page > 1:
            strsws = get_cache('zbstrsws')
            del_cache('zbstrsws')
        sws = strsws.split(',')
        contents = []
        keyword = keyword.replace('/', '%2F')
        with concurrent.futures.ThreadPoolExecutor(max_workers=thlimit) as executor:
            searchList = []
            try:
                for sw in sws:
                    num = sws.index(sw)
                    tag = sw
                    api = ''
                    future = executor.submit(self.runSearch, keyword, tag, page, num, api)
                    searchList.append(future)
                for future in concurrent.futures.as_completed(searchList, timeout=10):  # 并发执行
                    contents.append(future.result())
            except Exception:
                executor.shutdown(wait=False)
        nextpageList = []
        for content in contents:
            if content is None:
                continue
            key = list(content.keys())[0]
            infos = content[key]
            items = items + content[key][0]
            nextpageList.append(infos[1])
            if not infos[1]:
                strsws = strsws.replace(key, '').replace(',,', ',').strip(',')
        set_cache('zbstrsws', strsws)
        if True in nextpageList:
            has_next_page = True
        else:
            has_next_page = False
        return items, has_next_page

    def runSearch(self, keyword, tag, page, num, api):
        try:
            funList = dir(SpiderZhiBo)
            defname = 'self.search' + tag
            if defname.replace('self.', '') in funList and tag != '':
                result = eval(defname)(keyword, tag, page, num, api)
                return result
        except Exception:
            return {tag: [[], False]}

    def searchbb(self, keyword, tag, page, num, api):
        r = requests.get(
            'https://api.bilibili.com/x/web-interface/search/type',
            params={
                'page': page,
                'page_size': 10,
                'order': 'online',
                'search_type': 'live_user',
                'keyword': keyword,
            },
            headers={'Cookie': 'buvid3=0'})
        data = r.json()
        if page < data['data']['numPages']:
            nexpage = True
        else:
            nexpage = False
        items = []
        for room in data['data']['result']:
            remark = remove_html_tags(room['cate_name'])
            if remark == '':
                remark = '其他'
            items.append(
                SpiderItem(type=SpiderItemType.Directory,
                           id=room['roomid'],
                           name='B站：{}'.format(remove_html_tags(room['uname'])),
                           cover='https:' + room['uface'],
                           description='类型：' + remark,
                           params={
                               'pf': 'bilibili',
                               'type': 'video',
                               'num': num
                           },
                           sources=[
                               SpiderSource(
                                   room['roomid'],
                                   {
                                       'id': room['roomid'],
                                       'pf': 'bilibili',
                                       'num': num
                                   },
                               )
                           ]))
        return {tag: [items, nexpage]}

    def searchdy(self, keyword, tag, page, num, api):
        r = requests.get('https://www.douyu.com/japi/search/api/searchUser',
                         params={
                             'kw': keyword,
                             'page': page,
                             'pageSize': 10,
                             'filterType': 1
                         })
        data = r.json()
        if page * 10 < data['data']['total']:
            nexpage = True
        else:
            nexpage = False
        items = []
        for room in data['data']['relateUser']:
            if room['anchorInfo']['isLive'] != 1:
                continue
            items.append(
                SpiderItem(type=SpiderItemType.Directory,
                           id=room['anchorInfo']['rid'],
                           name='斗鱼：{}'.format(room['anchorInfo']['nickName']),
                           description='主播：' + room['anchorInfo']['cateName'],
                           cover=room['anchorInfo']['roomSrc'],
                           params={
                               'pf': 'douyu',
                               'type': 'video',
                               'num': num
                           },
                           sources=[
                               SpiderSource(
                                   room['anchorInfo']['rid'],
                                   {
                                       'id': room['anchorInfo']['rid'],
                                       'pf': 'douyu',
                                       'num': num
                                   },
                               )
                           ]))
        return {tag: [items, nexpage]}

    def searchhy(self, keyword, tag, page, num, api):
        r = requests.get('https://search.cdn.huya.com/',
                         params={
                             'm': 'Search',
                             'do': 'getSearchContent',
                             'typ': -5,
                             'livestate': 1,
                             'q': keyword,
                             'start': (page - 1) * 40,
                             'rows': 40
                         })
        data = r.json()
        if page * 40 < data['response']['1']['numFound']:
            nexpage = True
        else:
            nexpage = False
        items = []
        for room in data['response']['1']['docs']:
            items.append(
                SpiderItem(type=SpiderItemType.Directory,
                           id=room['room_id'],
                           name='虎牙：{}'.format(room['game_nick']),
                           description='类型：' + room['game_name'],
                           cover=room['game_avatarUrl180'],
                           params={
                               'pf': 'huya',
                               'type': 'video',
                               'num': num
                           },
                           sources=[
                               SpiderSource(
                                   room['room_id'],
                                   {
                                       'id': room['room_id'],
                                       'pf': 'huya',
                                       'num': num
                                   },
                               )
                           ]))
        return {tag: [items, nexpage]}

    def checkPurl(self, source_params, tag):
        header = {
            "Connection": "keep-alive",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
        }
        try:
            if source_params['pf'] == 'huya':
                header['Referer'] = 'https://www.huya.com/'
                tspList = self.readM3U8(source_params['url'], header, tag)
                return [tspList[0], source_params['url']]
            else:
                tspList = self.readM3U8(source_params['url'], header, tag)
                return [tspList[0], source_params['url']]
        except:
            return [{tag: 0}, '']

    def readM3U8(self, url, header, tag):
        url = url.strip('/')
        try:
            r = requests.get(url, headers=header, stream=True, allow_redirects=False, verify=False, timeout=5)
            if 'Content-Type' in r.headers and 'video' in r.headers['Content-Type']:
                r.close()
                return self.SpeedInfo(url, header, tag, url)
            elif 'Location' in r.headers and '#EXTM3U' not in r.text:
                r.close()
                url = r.headers['Location']
                r = requests.get(url, headers=header, stream=True, allow_redirects=False, verify=False, timeout=5)
            for line in r.iter_lines(8096):
                line = line.decode('utf-8', 'ignore')
                if len(line) > 0 and not line.startswith('#'):
                    if not line.startswith('http'):
                        if line.startswith('/'):
                            line = url[:url.index('/', 8)] + line
                        else:
                            line = url[:url.rindex('/') + 1] + line
                    if line.find(".m3u") != -1 and line.find(".ts") == -1:
                        r.close()
                        return self.readM3U8(line, header, tag)
                    if '.key' not in line:
                        r.close()
                    return self.SpeedInfo(line, header, tag, url)
        except:
            try:
                r.close()
            except:
                pass
            return {tag: 0}

    def SpeedInfo(self, url, header, tag, purl):
        r = requests.get(url, stream=True, headers=header, verify=False, timeout=5)
        count = 0
        count_tmp = 0
        stime = time.time()
        i = 0
        speed = 0
        proxy = 'nomral'
        for chunk in r.iter_content(chunk_size=40960):
            if chunk:
                if i == 2:
                    break
                count += len(chunk)
                sptime = time.time() - stime
                if chunk.startswith(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46') or chunk.startswith(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A') or chunk.startswith(b'\x42\x4D') or chunk.startswith(b'\x47\x49\x46\x38') or chunk.startswith(b'\x4D\x4D') or chunk.startswith(b'\x49\x49') or chunk.startswith(b'\x00\x00\x01\x00') or chunk.startswith(b'\x47'):
                    proxy = 'proxy'
                if count == int(r.headers['content-length']):
                    if sptime > 0:
                        speed = int((count - count_tmp) / sptime)
                    else:
                        speed = 1572864
                if sptime > 0:
                    speed = int((count - count_tmp) / sptime)
                    stime = time.time()
                    count_tmp = count
                    i = i + 1
        try:
            r.close()
        except:
            pass
        return [{tag: speed}, purl, proxy]

