import xbmc
import xbmcaddon
_ADDON = xbmcaddon.Addon()
if _ADDON.getSettingBool('autostart'):
    addonpath = _ADDON.getSettingString('select')
    xbmc.executebuiltin('ActivateWindow(Videos, "plugin://{}")'.format(addonpath))