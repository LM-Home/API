import sub_provider_service

sub_provider_service.run()
